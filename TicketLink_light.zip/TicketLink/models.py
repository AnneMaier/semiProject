from django.db import models
from django.db.models.signals import post_delete
from django.dispatch import receiver
from django.core.validators import MinValueValidator, MaxValueValidator


#회원, vip, 은행(증빙서류 중)
class AgBigCate(models.Model):
    agbigcate_no = models.BigAutoField(primary_key=True, verbose_name="약관대분류번호")
    agbigcate_name = models.CharField(max_length=100, null=False, verbose_name="약관대분류명") 

class AgSmallCate(models.Model):
    agsmallcate_no = models.BigAutoField(primary_key=True, verbose_name="약관소분류번호")
    agbigcate_no = models.ForeignKey(AgBigCate,on_delete=models.CASCADE, verbose_name="약관대분류seq")
    agsmallcate_name = models.CharField(max_length=100, null=False, verbose_name="약관소분류명") 

class Agreement(models.Model):
    agreement_no = models.BigAutoField(primary_key=True, verbose_name="약관유형번호")
    agbigcate_name = models.CharField(max_length=100, null=False, verbose_name="약관대분류명") 
    agsmallcate_name = models.CharField(max_length=100, null=False, verbose_name="약관소분류명") 
    agreement_title = models.CharField(max_length=100, null=False, verbose_name="약관명")
    agreement_content = models.TextField(max_length=1000, null=False, verbose_name="약관내용")

class Payment(models.Model):
    payment_no = models.BigAutoField(primary_key=True, verbose_name="간편계좌번호")
    payment_method = models.CharField(max_length=100, null=False, verbose_name="지불방법")
    payment_content = models.IntegerField(null=True, verbose_name="지불방식정보")

class Vip(models.Model):
    vip_no = models.BigAutoField(primary_key=True, verbose_name="vip넘버")
    vip_grade = models.CharField(max_length=100, null=False, verbose_name="등급")
    required = models.CharField(max_length=500, null=False, verbose_name="자격조건")
    benefit = models.CharField(max_length=500, null=False, verbose_name="혜택")

class Member(models.Model):
    member_no = models.BigAutoField(primary_key=True, verbose_name="회원번호")
    email = models.CharField(max_length=100, null=False, verbose_name="이메일아이디")
    phone = models.IntegerField(null=True, verbose_name="휴대폰아이디")
    name = models.CharField(max_length=20, null=True, verbose_name="이름")
    password = models.CharField(max_length=100, null=False, verbose_name="비밀번호")
    birth = models.DateField(null=True, verbose_name="생년월일")
    gender = models.IntegerField(null=True, verbose_name="성별")
    foreign = models.IntegerField(null=True, verbose_name="내외국인여부")
    address = models.IntegerField(null=True, verbose_name="우편주소")
    address_detail = models.CharField(null=True, max_length=500, verbose_name="세부주소")
    vip = models.ForeignKey(Vip,on_delete=models.CASCADE, verbose_name="VIPseq")
    point = models.IntegerField(null=True, verbose_name="포인트")
    kind = models.IntegerField(null=True, verbose_name="관리자여부")
    # payment = models.ForeignKey(Payment,on_delete=models.CASCADE, verbose_name="간편결제seq")

class Agree(models.Model):
    agree_no = models.BigAutoField(primary_key=True, verbose_name="동의번호")
    agreement_no = models.ForeignKey(Agreement,on_delete=models.CASCADE, verbose_name="약관seq")
    member_no = models.ForeignKey(Member,on_delete=models.CASCADE, verbose_name="회원seq")
    
class Bank(models.Model):
    bank_no = models.BigAutoField(primary_key=True, verbose_name="은행번호")
    bank_name = models.CharField(max_length=20, null=False, verbose_name="은행명")

class RefundAccount(models.Model):
    account_no = models.BigAutoField(primary_key=True, verbose_name="환불계좌번호")
    member_no = models.ForeignKey(Member,on_delete=models.CASCADE, verbose_name="회원seq")
    bank_no = 	models.ForeignKey(Bank,on_delete=models.CASCADE, verbose_name="은행seq")
    account_num = models.IntegerField(null=False)

class withdraw(models.Model):
    withdraw_no	= models.BigAutoField(primary_key=True, verbose_name="탈퇴번호")
    member_no = models.ForeignKey(Member,on_delete=models.CASCADE, verbose_name="회원seq")
    withdraw_state = models.CharField(max_length=10, null=False, verbose_name="탈퇴상태")
    withdraw_date = models.DateField(null=True, verbose_name="탈퇴신청시기")

#공연파트 시작			
class RecieveWay(models.Model):
    no = models.BigAutoField(primary_key=True, verbose_name="티켓 수령방법 번호")
    rw_name = models.CharField(max_length=8, verbose_name="티켓 수령방법명")
    rw_charge = models.IntegerField(verbose_name="티켓 가격")


class Kind(models.Model):
    kind_no = models.AutoField(primary_key=True, blank=False, null=False, verbose_name="구분번호")                         
    kind_name = models.CharField(max_length=20, blank=False, null=False, verbose_name="구분명")                        


class Genre(models.Model):
    genre_no = models.BigAutoField(primary_key=True, blank=False, null=False, verbose_name="장르번호")
    gnr_name = models.CharField(blank=False, null=False, verbose_name="장르명",max_length=50)       #뮤지컬, 연극이 기준. 대학로 장르는 필요할 경우 check로 구현
    gnr_class = models.CharField(blank=True, null=True, verbose_name="장르내 분류",max_length=50)


class Region(models.Model):
    region_no = models.BigAutoField(primary_key=True, blank=False, null=False, verbose_name="지역번호")
    region_name = models.CharField(blank=False, null=False, verbose_name="공연지역 이름", max_length=50)


class Place(models.Model):
    place_no = models.BigAutoField(primary_key=True, blank=False, null=False, verbose_name="공연장소 번호")
    plc_name = models.CharField(max_length=200, blank=False, null=False, verbose_name="공연장 명")
    plc_address = models.CharField(max_length=200, blank=False, null=False, verbose_name="공연장 주소")
    plc_call = models.CharField(max_length=200, blank=True, null=True, verbose_name="공연장 대표번호")
    plc_logo = models.FileField(blank=True, null=True, verbose_name="공연장 로고")
    plc_count = models.BigIntegerField(blank=True, null=True, verbose_name="공연장 총 좌석")
    region_no = models.ForeignKey(Region, on_delete=models.CASCADE, verbose_name="지역번호")




#휘찬님↓

class Perform(models.Model):
    perform_no = models.BigAutoField(primary_key=True, blank=False, null=False, verbose_name="공연번호")                    
    place_no = models.ForeignKey(Place, on_delete=models.CASCADE, verbose_name="공연장소")              
    poster = models.FileField(null=False, verbose_name="공연포스터")                                                           
    poster2 = models.FileField(null=True, verbose_name="공연 메인 홈 포스터")
    pf_name = models.CharField(max_length=300, blank=False, null=False, verbose_name="공연이름")                              
    genre_no = models.ForeignKey(Genre, on_delete=models.CASCADE, verbose_name="공연장르")                                   
    promo= models.TextField (blank=True, null=True, verbose_name="프로모션 번호")                                                                    
    kind_no = models.ForeignKey(Kind, on_delete=models.CASCADE, verbose_name="구분번호")                                     
    pf_ticketdate = models.DateTimeField(null=False, verbose_name="티켓오픈날짜")                                                   
    pf_startdate = models.DateField(null=False, verbose_name="공연시작일")                                                     
    pf_enddate = models.DateField(null=False, verbose_name="공연끝나는날")                                                       
    pf_rating = models.CharField(max_length=200, blank=True, null=True, verbose_name="관람등급")    
    pf_time = models.CharField(max_length=30, blank=True, null=True, verbose_name="관람시간")                 
    pftime_info = models.TextField(blank=True, null=True, verbose_name="공연시간정보")                           
    notice = models.TextField(blank=False, null=False, verbose_name="공지사항")                              
    saleimg_info = models.FileField(null=True, verbose_name="공연할인정보(이미지)")
    saletxt_info = models.TextField(null=True, blank=True, verbose_name="공연할인정보(텍스트)")                                                         
    pf_info = models.FileField(null=False, verbose_name="작품상세정보")
    host = models.CharField(max_length=400, blank=False, null=False, verbose_name="주최 및 기획")
    inquiry = models.CharField(max_length=50, blank=False, null=False, verbose_name="고객문의")
    main_actor = models.CharField(max_length=500, blank=True, null=True, verbose_name="주연")
    booking_fee = models.BigIntegerField(blank=True, null=True, verbose_name="예매수수료")
    rw_no = models.ForeignKey(RecieveWay, on_delete=models.CASCADE, verbose_name="배송방법")
    exp_date = models.CharField(max_length=200, blank=False, null=False, verbose_name="유효기간")
    # ct_policy = models.CharField(max_length=500, blank=False, null=False, verbose_name="예매취소조건")
    # ct_info = models.TextField(blank=False, null=False, verbose_name="취소환불방법")          #html, layout처리
    uploadDate = models.DateTimeField(auto_now_add=True, null=False, verbose_name="공연등록날짜")
    character = models.CharField(max_length=300, blank=False, null=False, verbose_name="특징")                              


class Promotion(models.Model):    
    promo_no = models.AutoField(primary_key=True, blank=False, null=False, verbose_name="프로모션 번호")
    promo_name = models.CharField(max_length=200, blank=True, null=True, verbose_name="프로모션 이름")


class Role(models.Model):
    role_no = models.BigAutoField(primary_key=True, blank=False, null=False)
    perform_no = models.ForeignKey(Perform, on_delete=models.CASCADE, verbose_name="공연전시")
    actors_name = models.CharField(max_length=100, blank=False, null=False, verbose_name="배우 이름")
    role_name = models.CharField(max_length=100, blank=False, null=False, verbose_name="배역 명")
    role_th = models.IntegerField(blank=False, null=False, verbose_name="해당 배역의 순서")
    role_picture = models.FileField(null=False, verbose_name="배역 대표 사진")



class PerformRound(models.Model): 
    no = models.BigAutoField(primary_key=True, verbose_name="공연회차 번호")
    perform_no = models.ForeignKey(Perform,on_delete=models.CASCADE, verbose_name="공연/전시seq") 
    pfr_date = models.DateField(null=True, verbose_name="공연 날짜")
    pfr_starttime = models.TimeField(null=True, verbose_name="해당 회차 시작 시간") 
    pfr_rolelist = models.TextField(max_length=40, null=True, verbose_name="배역 list") 
    pfr_round = models.IntegerField(null=True, verbose_name="당일의 회차 번호") 


class SeatType(models.Model):
    no = models.BigAutoField(primary_key=True, verbose_name="공연/전시 좌석유형 번호")
    perform_no = models.ForeignKey(Perform,on_delete=models.CASCADE, verbose_name="공연/전시seq")
    seatType_name = models.CharField(max_length=20, verbose_name="좌석등급") 
    seatType_price = models.IntegerField(verbose_name="좌석 등급 가격") 


class Seat(models.Model): #공연회차별 좌석 정보 테이블
    no = models.BigAutoField(primary_key=True, verbose_name="공연/전시좌석 고유번호")
    pfr_no = models.ForeignKey(PerformRound, on_delete=models.CASCADE, verbose_name="공연회차 seq")
    seatType_no = models.ForeignKey(SeatType, on_delete=models.CASCADE, null=True, verbose_name="공연/전시좌석유형 seq")
    seat_name = models.CharField(max_length=8, verbose_name="좌석명")
    seat_state = models.BooleanField(default=False, verbose_name="좌석 예매 상태")
    seat_cts = models.IntegerField(default=0, verbose_name="취소표 대기 수", validators=[MinValueValidator(0), MaxValueValidator(5)])

# 예매/예매 취소



class Booking(models.Model):
    no = models.BigAutoField(primary_key=True, verbose_name="공연/전시 예약번호")
    member_no = models.ForeignKey(Member,on_delete=models.CASCADE, verbose_name="회원seq")
    pfr_no = models.ForeignKey(PerformRound, on_delete=models.CASCADE, verbose_name="공연회차seq")
    rw_no = models.ForeignKey(RecieveWay, on_delete=models.CASCADE, verbose_name="티켓 수령방법seq")
    bk_tknum = models.IntegerField( validators=[MinValueValidator(1), MaxValueValidator(4)],verbose_name="예약한 티켓 수")
    bk_seats = models.TextField(null=True, verbose_name="예약한 좌석 list")
    bk_total = models.IntegerField(verbose_name="총 결제 금액")
    bk_info = models.TextField(verbose_name="예약 상세 정보")
    bk_datetime = models.DateTimeField(auto_now_add=True, verbose_name="예약한 날짜/시간")
    bk_state = models.BooleanField(default=True, verbose_name="예약 상태")
    bk_bkname = models.TextField(null=True, verbose_name="주문자 이름")
    bk_bkphone = models.TextField(null=True, verbose_name="주문자 전화번호")
    bk_bkemail = models.TextField(null=True, verbose_name="주문자 이메일")
    bk_rw_name = models.TextField(null=True, verbose_name="배송정보 이름")
    bk_rw_phone = models.TextField(null=True, verbose_name="배송정보 전화번호")
    bk_rw_address = models.TextField(null=True, verbose_name="배송정보 주소")
    bk_rw_zipcode = models.TextField(null=True, verbose_name="배송정보 우편번호")




class PerformCharge0(models.Model):
    no = models.BigAutoField(primary_key=True, verbose_name="공연 할인 번호")
    perform_no = models.ForeignKey(Perform,on_delete=models.CASCADE, verbose_name="공연/전시 seq")
    pc0_name = models.CharField(verbose_name="할인명", max_length=300)
    pc0_seats = models.CharField(verbose_name="적용되는 좌석 list", max_length=300)
    pc0_rate = models.FloatField(verbose_name="할인율")
    pc0_rounds = models.TextField(null=True, verbose_name="적용되는 회차 list")


class PerformCharge1(models.Model):
    no = models.BigAutoField(primary_key=True, verbose_name="전시 티켓 정보")
    perform_no = models.ForeignKey(Perform,on_delete=models.CASCADE, verbose_name="공연/전시 seq")
    pc1_name = models.CharField(verbose_name="티켓명", max_length=300)
    pc1_price = models.IntegerField(verbose_name="티켓 가격")
    pc1_kind =  models.IntegerField(null=True, verbose_name="티켓 종류(일반/할인)" )


class CancelType(models.Model):
    no = models.BigAutoField(primary_key=True, verbose_name="취소 유형 번호")
    ct_name = models.CharField(verbose_name="취소 유형명", max_length=100)
    ct_rate = models.FloatField(null=True, verbose_name="취소 수수료(비율)")
    ct_charge = models.IntegerField(null=True,validators=[MaxValueValidator(4000)], verbose_name="취소 수수료(고정값)")


class BkCancel(models.Model):
    no = models.BigAutoField(primary_key=True, verbose_name="공연/전시취소 신청 번호")
    bk_no = models.ForeignKey(Booking,on_delete=models.CASCADE, verbose_name="공연/전시 예약 seq")
    bkc_datetime = models.DateTimeField(auto_now_add=True, verbose_name="예약 취소한 날짜/시간")
    ct_no = models.ForeignKey(CancelType,on_delete=models.CASCADE, verbose_name="취소 유형 seq")
    bkc_refund = models.IntegerField(verbose_name="환불 금액")
    bkc_bank = models.CharField(verbose_name="환불 은행명", max_length=10)
    bkc_account = models.CharField(verbose_name="환불 계좌번호",max_length=40)


# 취소표/우선권 

class CancelTicket(models.Model):
    no = models.BigAutoField(primary_key=True, verbose_name="취소표 신청 번호")
    member_no = models.ForeignKey(Member,on_delete=models.CASCADE, verbose_name="회원 seq")
    pfr_no = models.ForeignKey(PerformRound, on_delete=models.CASCADE, verbose_name="공연/전시 회차seq")
    cct_num = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(4)], verbose_name="신청한 대기표 수")
    cct_seats = models.TextField(verbose_name="대기 신청한 좌석 list")
    cct_phone = models.CharField(verbose_name="연락받을 전화번호",max_length=40)
    cct_address = models.CharField(verbose_name="연락받을 이메일",max_length=40)
    cct_charge = models.IntegerField(verbose_name="취소표 신청 요금")
    cct_priorty = models.IntegerField( validators=[MinValueValidator(1)], verbose_name="취소표 우선 순위")
    cct_state = models.IntegerField(default=0, verbose_name="취소표 대기 상태, 0일 경우 우선순위 배정 x, 1일경우 배정된 상태, 2일경우 사용완료")
    
class Priorty(models.Model):
    no = models.BigAutoField(primary_key=True, verbose_name="우선예약권 번호")
    cct_no = models.ForeignKey(CancelTicket, on_delete=models.CASCADE, verbose_name="취소표 신청 seq")
    pfr_no = models.ForeignKey(PerformRound, on_delete=models.CASCADE, verbose_name="공연/전시 회차seq")
    pr_datetime = models.DateTimeField(auto_now_add=True, verbose_name="예약 우선권 부여된 날짜/시간")
    pr_seats = models.TextField(verbose_name="우선권이 부여된 좌석 list")


class WriteType(models.Model):
    writetype_no = models.BigAutoField(primary_key=True, verbose_name="유형번호")
    type_name = models.CharField(max_length=10, null=False, verbose_name="유형명")

class Write(models.Model):
    write_no = models.BigAutoField(primary_key=True, verbose_name="글번호")
    writetype_no = models.ForeignKey(WriteType,on_delete=models.CASCADE, verbose_name="글유형seq")
    member_no = models.ForeignKey(Member,on_delete=models.CASCADE, verbose_name="회원seq")
    perform_no = models.ForeignKey(Perform,on_delete=models.CASCADE, verbose_name="공연seq")
    score = models.IntegerField(null=True, verbose_name="평점")
    write_content = models.CharField(max_length=1000, null=False, verbose_name="글내용")
    write_date = models.DateTimeField(auto_now_add=True, verbose_name="작성일")


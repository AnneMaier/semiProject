from django.shortcuts import render, redirect
from django.http import HttpRequest, HttpResponse, JsonResponse
from TicketLink.models import Member, Perform, Genre, PerformRound
import random, json, re
from datetime import datetime, timedelta

def index(request:HttpRequest):
    show = ''
    member = ''
    try:
        member = Member.objects.get(member_no = request.session.get('login'))
        id = member.email
        key = id.find("@")
        for i in range(id.__len__()):
            if i < key and i >= key/2:
                show += '*'
            else:
                show += id[i]
    except:
        pass


    pf_no = request.GET.get('pf_no')
    gr_no= request.GET.get('gr_no')


    perform_all = Perform.objects.all()
    perform_all_su= 0
    perform_recommend = []
    perform_recommend_su = []

    perform = Perform.objects.filter(perform_no=pf_no)
    genre = Genre.objects.filter(genre_no = gr_no)

    for i in perform_all:

        perform_all_su+=1

    while perform_recommend.__len__() < 5:
        perform_rannum = random.randint(1,perform_all_su)
        if perform_rannum in perform_recommend_su:
            continue
        else:
            perform_recommend.append(Perform.objects.get(perform_no=perform_rannum))
            perform_recommend_su.append(perform_rannum)

 
    context={
        "id" : show,
        "member" : member,
        "perform_all" : perform_all,
        "recommend" : perform_recommend,
        "perform" : perform,
        "genre" : genre,

    }
    return render(request,'index.html', context)
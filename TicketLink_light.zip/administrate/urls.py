from django.urls import path
from . import views
from django.conf import settings

urlpatterns = [
    path('perform/',views.perform),
    path('perform/add/',views.pf_add),
    path('perform/add/product/',views.pf_add_product),
    path('perform/add/productCK/',views.pf_add_productCK),
    path('perform/add/round/',views.pf_add_round),
    path('perform/add/round/roleAjax/',views.roleAjax),
    path('perform/add/roundCK/',views.pf_add_roundCK),
    path('travel/',views.travel),
    path('member/',views.member),
    path('member/info/',views.info),
    path('member/info/result/',views.infoResult),
    path('member/book/',views.book),
    path('member/review/',views.review),
    path('member/review/result/',views.reviewResult),
    path('member/draw/',views.draw),
    path('member/draw/result/',views.drawResult),
]
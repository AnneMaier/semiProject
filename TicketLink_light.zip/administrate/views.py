from django.shortcuts import render, redirect
from django.http import HttpRequest, JsonResponse

from TicketLink.models import Member, withdraw, Booking
# from TicketLink.models import InquiryStep, Inquiry, Answer
# from TicketLink.models import Event, EventCate, EventEntry
from TicketLink.models import Perform, Write
from TicketLink.models import Role, Perform,Kind, PerformRound, SeatType, Role, PerformRound, Promotion, Write , Place, Seat, Genre, RecieveWay, Booking
from datetime import time
from django.core.paginator import Paginator

# Create perform views here.

def perform(request:HttpRequest):
    member = Member.objects.get(member_no = request.session.get('login'))

    context = {
        "member" : member,

    }
    return render(request, 'administrate/perform/index.html', context)

def pf_add(request:HttpRequest):
    member = Member.objects.get(member_no = request.session.get('login'))

    context = {
        "member" : member,

    }
    return render(request, 'administrate/perform/add/index.html', context)


def pf_add_product(request:HttpRequest):

    member = Member.objects.get(member_no = request.session.get('login'))
    promo = Promotion.objects.all()
    place = Place.objects.all()
    genre = Genre.objects.all()
    recieveway = RecieveWay.objects.all()


    context = {
        "member" : member,
        "promo" : promo,
        "place" :place,
        "genre" : genre,
        "recieveway" : recieveway,
 


    }
    return render(request, 'administrate/perform/add/product.html', context)

def pf_add_productCK(request:HttpRequest):
    kind_no = request.POST.get('pf_kind')
    kind = Kind.objects.get(kind_no = kind_no)
    promo_su = request.POST.get('promo_su')
    promo = []
    if promo_su == '0':
        if request.POST.get('promo_0') == '0':
            promo = None
        else:
            promo = [int(request.POST.get('promo_0'))]
    else:
        i = 0
        while i < int(promo_su):
            x = request.POST.get('promo_'+str(i))
            promo.append(int(x))
            i += 1

    place_no = request.POST.get('pf_place')
    place = Place.objects.get(place_no=place_no)
    genre_no = request.POST.get('pf_genre')
    genre = Genre.objects.get(genre_no=genre_no)
    recieveway_no = request.POST.get('pf_recieveway')
    rw = RecieveWay.objects.get(no=recieveway_no)
    name = request.POST.get('pf_name')
    rating = request.POST.get('pf_rating')
    fulltime = request.POST.get('pf_time')
    pftime_info_text = request.POST.get('pf_pftime_info_text')
    bk_fee = request.POST.get('pf_booking_fee')
    exp_date = request.POST.get('pf_exp_date')
    sale_text = request.POST.get('pf_sale_text')
    notice = request.POST.get('pf_notice')
    host = request.POST.get('pf_host')
    inquiry = request.POST.get('pf_inqury')
    mainactor = request.POST.get('pf_mainactor')
    character = request.POST.get('pf_charactor')
    poster1 = request.POST.get('pf_poster1')
    poster2 = request.POST.get('pf_poster2')

    # pftime_info_img = request.FILES.get('pf_pftime_info_img')
    sale_img = request.POST.get('pf_sale_img')
    info_img = request.POST.get('pf_info_img')
    ticket_date = request.POST.get('pf_ticketdate')
    start_date = request.POST.get('pf_startdate')
    end_date = request.POST.get('pf_enddate')
    print(poster1)
    print(name)

        
        
    try:
        newperform = Perform.objects.create(place_no=place,poster=poster1,poster2=poster2,
        pf_name=name,genre_no=genre,promo=promo,kind_no=kind, pf_ticketdate=ticket_date,
        pf_startdate= start_date,pf_enddate= end_date,pf_rating=rating,pf_time=fulltime,
        pftime_info=pftime_info_text, notice=notice,saleimg_info = sale_img,saletxt_info=sale_text,
        pf_info=info_img,host=host,inquiry=inquiry,main_actor=mainactor,booking_fee=bk_fee,rw_no=rw,
        exp_date=exp_date,character=character)
        message = "공연이 생성되었습니다!"
    except Exception as e:
        print('공연 생성 실패')
        print(e)
        return redirect('/administrate/perform/add/product/')
    
    if kind.kind_no == 2:
        newPfr = PerformRound.objects.create(pfr_round=1,perform_no=newperform)
        message = "전시가 생성되어 임시 회차가 함께 생성되었습니다."
        

    
   
    context = {
        "message" : message
    }
    return render(request, 'administrate/perform/add/check.html', context)

def pf_add_round(request:HttpRequest):

    perform = Perform.objects.filter(kind_no=1)
    hours = []
    hr = -1
    while hr < 23:
        hr += 1
        hours.append(hr)
    minuates = []
    mt = -1
    while mt < 59:
        mt += 1
        minuates.append(mt)
    
    role = Role.objects.all
    seatType = SeatType.objects.all

    context = {
    "perform" : perform,
    "hours" : hours,
    "minuates" :minuates,
    "role" : role,
    "seattype" : seatType

    }

    return render(request, 'administrate/perform/add/round.html', context)


def roleAjax(request:HttpRequest):
    role_pks = []
    seat_type_pks = []
    perform_no = request.POST.get('data')
    print(perform_no)
    roles = Role.objects.filter(perform_no=int(perform_no))
    perform = Perform.objects.get(perform_no=int(perform_no))
    
    if perform.kind_no.kind_no == 1:
        kind = 1
    else:
        kind = 2

    for i in roles:
        role_pks.append(i.role_no)
    seat_types = SeatType.objects.filter(perform_no=int(perform_no))
    for i in seat_types:
        seat_type_pks.append(i.no)
    
    print(kind)
    return JsonResponse({
        "role_pks" : role_pks,
        "seat_type_pks" : seat_type_pks,
        "kind" : kind
      
        })


def pf_add_roundCK(request:HttpRequest):
    pf_no = request.POST.get('pf_no')
    pfr_date = request.POST.get('pfr_ticketdate')
    pfr_hour = request.POST.get('pfr_hour')
    pfr_minuate = request.POST.get('pfr_minuate')
    selected_role_list = request.POST.get('selected_rolelist_inform')
    pfr_round = request.POST.get('pfr_round')
    seat_su = request.POST.get('seattype_su')
    pf = Perform.objects.get(perform_no=pf_no)
    print(pf_no)
    print(pfr_date)
    print(pfr_hour)
    print(pfr_minuate)
    print('['+(selected_role_list)+']')
    print(pfr_round)
    print(seat_su)

        

    # 시간 객체 생성
    time_obj = time(hour=int(pfr_hour), minute=int(pfr_minuate))
    print(time_obj)

    try:
        newPerformRound = PerformRound.objects.create(perform_no=pf,pfr_date=pfr_date,
        pfr_starttime=time_obj,pfr_rolelist=('['+(selected_role_list)+']'),pfr_round=pfr_round)
    except Exception as e:
        print('공연회차 생성 실패')
        print(e)
        return redirect('/administrate/perform/add/round/')

 
    i = 0
    while i < int(seat_su):
        print('시작')
        seatname = request.POST.get('seatname_'+str(i))
        seat_sel = request.POST.get('seattype_sel_'+str(i))
        seat_sel_su = request.POST.get('seat_su_'+str(i))
        print(seatname)
        print(seat_sel)
        print(seat_sel_su)
        stType = SeatType.objects.get(no=int(seat_sel))
        j = 1
        while j < int(seat_sel_su)+1:
            try: newSeat = Seat.objects.create(pfr_no=newPerformRound,seat_name=(seatname+str(j)),seat_state=0,seat_cts=0,seatType_no=stType)
            except Exception as e:
                print('좌석 생성 실패!')
                print(e)
                return redirect('/administrate/perform/add/round/')
            j += 1

        i += 1
    
    message = "회차 및 좌석을 생성하는데 성공했습니다!"
        

    context = {
        "message" : message
        
    }

    return render(request, 'administrate/perform/add/check.html', context)

# Create travel views here.

def travel(request:HttpRequest):
    member = Member.objects.get(member_no = request.session.get('login'))

    context = {
        "member" : member,

    }
    return render(request, 'administrate/travel/index.html', context)



    
# Create member views here.

def member(request:HttpRequest):
    # member = Member.objects.get(member_no = request.session.get('login'))
    memberAll = Member.objects.all()
    draw = withdraw.objects.all()
    # inquire = Inquiry.objects.all()
    # event = Event.objects.all()

    MAX_PAGE_CNT = 10
    MAX_LIST_CNT = 5
    paginator = Paginator(memberAll,MAX_LIST_CNT)
    page = request.GET.get('page','1')
    page_obj = paginator.get_page(page)
    last_page = paginator.num_pages
    current_block = (int(page) - 1) // MAX_PAGE_CNT + 1
    start_page = (current_block - 1) * MAX_PAGE_CNT + 1
    end_page = start_page + MAX_PAGE_CNT -1      

    context = {
        "list" : page_obj,
        "last_page" : last_page,
        "start_page" : start_page,
        "end_page" : end_page,

        "draw" : draw,
        # "inquire" : inquire,
        # "event" : event,

    }
    return render(request, 'administrate/member/index.html', context)


def info(request:HttpRequest):
    member = Member.objects.get(member_no = request.session.get('login'))
    no = request.GET.get("no")
    target = Member.objects.get(member_no = no)

    birth_month = target.birth.month
    if str(birth_month).__len__() == 1:
        birth_month = "0{}".format(target.birth.month)
    birth_day = target.birth.day
    if str(birth_day).__len__() == 1:
        birth_day = "0{}".format(target.birth.day)
    target_birth = "{}-{}-{}".format(target.birth.year,birth_month,birth_day)

    context = {
        "member" : member,
        "target" : target,
        "target_birth" : target_birth,

    }
    return render(request, 'administrate/member/memberInfo/info.html', context)

def infoResult(request:HttpRequest):
    no = request.POST.get('no')
    member = Member.objects.get(member_no = no)
    msg = "Error"
    url = "/administrate/member/"

    email = request.POST.get('email')
    phone = request.POST.get('phone')
    birth = request.POST.get('birth')
    gender = request.POST.get('gender')
    foreign = request.POST.get('foreign')
    address = request.POST.get('address')
    kind = request.POST.get('kind')

    print("{},{},{},{},{},{},{}".format(email, phone, birth, gender,foreign, address, kind))

    try:
        member.email = email
        member.phone = phone
        member.birth = birth
        member.gender = gender
        member.foreign = foreign
        member.address = address
        member.kind = kind
        member.save()
    except Exception as e:
        print(e)
        msg = "회원 정보 수정에 실패했습니다."
    else:
        msg = "회원 정보 수정에 성공했습니다."
        request.session['login_kind'] = member.kind
        request.session['login_email'] = member.email

    context = {
        "member" : member,
        "msg" : msg,
        "url" : url,
    }
    return render(request, 'administrate/member/result.html', context)


def book(request:HttpRequest):
    member = Member.objects.get(member_no = request.session.get('login'))
    no = request.GET.get("no")
    target = Member.objects.get(member_no = no)
    booking = Booking.objects.filter(member_no = target.member_no)

    context = {
        "member" : member,
        "target" : target,
        "booking" : booking,
    }
    return render(request, 'administrate/member/memberInfo/book.html', context)


def review(request:HttpRequest):
    member = Member.objects.get(member_no = request.session.get('login'))
    no = request.GET.get("no")
    target = Member.objects.get(member_no = no)
    write = Write.objects.filter(member_no = no)

    context = {
        "member" : member,
        "target" : target,
        "write" : write,
    }
    return render(request, 'administrate/member/memberInfo/review.html', context)

def reviewResult(request:HttpRequest):

    no = request.POST.get('no')
    content = request.POST.get("content")
    score = request.POST.get("score")
    write = Write.objects.get(write_no = no)
    msg = "Error"
    url = "/administrate/member/"

    try:
        write.write_content = content
        if score != None:
            write.score = score
        write.save()
    except Exception as e:
        print(e)
        msg = "후기/기대평 수정에 실패했습니다."
    else:
        msg = "후기/기대평 수정에 성공했습니다."

    context = {
        "msg" : msg,
        "url" : url,
    }
    return render(request, 'administrate/member/result.html', context)    


def draw(request:HttpRequest):
    member = Member.objects.get(member_no = request.session.get('login'))
    no = request.GET.get("no")
    target = Member.objects.get(member_no = no)
    draw = withdraw.objects.get(member_no = target)
    context = {
        "target" : target,
        "draw" : draw,
    }
    return render(request, 'administrate/member/memberInfo/draw.html', context)

def drawResult(request:HttpRequest):
    no = request.POST.get('no')
    target = Member.objects.get(member_no = no)
    msg = "Error"
    url = "/administrate/member/"

    try:
        target.delete()
    except Exception as e:
        print(e)
        msg = "탈퇴에 실패하였습니다."
    else:
        msg = "탈퇴 되었습니다"

    context = {
        "msg" : msg,
        "url" : url,
    }
    return render(request, 'administrate/member/memberInfo/result.html', context)    



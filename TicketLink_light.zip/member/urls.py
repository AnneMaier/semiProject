from django.urls import path,include
from django.conf.urls.static import static
from . import views
from django.conf import settings

urlpatterns = [
    path('',views.index),
    path('login/',views.login),
    path('login/result/',views.loginResult),
    path('logout/',views.logout),
    path('join/',views.join),
    path('join/form/',views.joinForm),
    path('join/result/',views.joinResult),
    path('certify/',views.certify),
    path('certify/result/',views.certifyResult),
    path('find/',views.find),
    path('find/pwchange/',views.findPwchange),
    path('find/idresult/',views.findIdresult),
    path('find/pwresult/',views.findPwresult),
    path('find/pwcomplite/',views.findPwcomplite),

]
from django.shortcuts import render, redirect
from django.http import HttpRequest,HttpResponse, JsonResponse
from TicketLink.models import Member, Agreement, Agree, Vip
from datetime import date, datetime, timedelta
from random import random, randint, randrange

# Create your views here.
def index(request:HttpRequest):
    return render(request, 'member/index.html')

def login(request:HttpRequest):
    return render(request, 'member/login/form.html')

def loginResult(request:HttpRequest):
    id = request.POST.get('id')
    pw = request.POST.get('pw')
    check = True
    msg = ''
    try:
        member = Member.objects.get(email=id, password=pw)
    except:
        check = False
        msg = "아이디 또는 비밀번호가 부정확합니다."
    else:
        request.session['login'] = member.member_no
        request.session['login_email'] = member.email
        request.session['login_kind'] = member.kind
    context = {
        "id" : id,
        "pw" : pw,
        "msg" : msg,
        "check" : check,
    }
    return render(request, 'member/login/result.html', context)

def logout(request:HttpRequest):
    request.session.pop('login')
    request.session.pop('login_email')
    request.session.pop('login_kind')
    return redirect('/')

def join(request:HttpRequest):
    randomNum = int(randrange(1000, 10000))
    print(randomNum)

    context = {
        'randomNum' : randomNum,
    }
    return render(request, 'member/join/check.html', context)

def joinForm(request:HttpRequest):
    num = request.POST.get('num')
    agreement = Agreement.objects.all()
    print(agreement[1].agreement_title)
    context = {
        'num' : num,
        'agreement' : agreement,
    }
    return render(request, 'member/join/form.html', context)

def joinResult(request:HttpRequest):
    id = request.POST.get('id')
    pw = request.POST.get('pw')
    a1 = request.POST.get('a1') #on | None
    a2 = request.POST.get('a2')
    a3 = request.POST.get('a3')
    a4 = request.POST.get('a4')
    vip_nomal = Vip.objects.get(vip_no = "1")
    a1seq = Agreement.objects.get(agreement_no = "1")
    a11seq = Agreement.objects.get(agreement_no = "6")
    a12seq = Agreement.objects.get(agreement_no = "7")
    a13seq = Agreement.objects.get(agreement_no = "8")
    a14seq = Agreement.objects.get(agreement_no = "9")
    a15seq = Agreement.objects.get(agreement_no = "10")
    now = datetime.now()
    now_date = now.strftime("%Y.%m.%d")
    try:
        member = Member.objects.create(email = id, password = pw, vip = vip_nomal, kind = 2)
    except Exception as e:
        print("계정 생성 실패")
        print(e)
        return redirect('/member/join/form/')
    else:
        try:
            Agree.objects.create(agreement_no = a1seq, member_no = member)
            Agree.objects.create(agreement_no = a11seq, member_no = member)
            Agree.objects.create(agreement_no = a12seq, member_no = member)
            Agree.objects.create(agreement_no = a13seq, member_no = member)
            Agree.objects.create(agreement_no = a14seq, member_no = member)
            Agree.objects.create(agreement_no = a15seq, member_no = member)
            if a2 == "on":
                a2seq = Agreement.objects.get(agreement_no = "11")
                Agree.objects.create(agreement_no = a2seq, member_no = member)
            if a3 == "on":
                a3seq = Agreement.objects.get(agreement_no = "12")
                Agree.objects.create(agreement_no = a3seq, member_no = member)
            if a4 == "on":
                a4seq = Agreement.objects.get(agreement_no = "13")
                Agree.objects.create(agreement_no = a4seq, member_no = member)
        except Exception as e:
            print("약관 동의 실패")
            print(e)
            return redirect('/member/join/form/')


    context = {
        'id' : id,
        'pw' : pw,
        'a1' : a1,
        'a4' : a4,
        'date' : now_date,
    }
    return render(request, 'member/join/result.html', context)

def certify(request:HttpRequest):
    agreement = Agreement.objects.all()
    id = request.GET.get('id')
    type = request.GET.get('type')
    print(type)
    
    context = {
        "agreement" : agreement,
        "id" : id,
        "type" : type,
    }
    return render(request, 'member/certify/form.html', context)

def certifyResult(request:HttpRequest):
    msg = ""
    msg_title = ""
    check = True
    type = request.GET.get('type')
    name = request.POST.get('name')
    birth = request.POST.get('birth')
    birth_y = "{}{}".format(birth[0],birth[1])
    birth_m = "{}{}".format(birth[2],birth[3])
    birth_d = "{}{}".format(birth[4],birth[5])
    gnf = request.POST.get('genderAndforeign')
    phone = request.POST.get('phone')
    print(type == 'findId')
    if type == 'join':
        id = request.POST.get('id')
        print(id)
        try:
            member = Member.objects.get(email = id)
            member.name = name
            if int(gnf) <= 2:
                birth_date = "19{}-{}-{}".format(birth_y, birth_m, birth_d)
                birth = datetime.strptime(birth_date,'%Y-%m-%d')
                member.birth = birth
            else:
                birth_date = "20{}-{}-{}".format(birth_y, birth_m, birth_d)
                birth = datetime.strptime(birth_date,'%Y-%m-%d')
                member.birth = birth
            if int(gnf)%2 == 1:
                member.gender = 1
            else:
                member.gender = 2
            if int(gnf) <= 5:
                member.foreign = 1
            else:
                member.foreign = 2
            member.phone = int(phone)
            member.save()
        except Exception as e:
            print(e)
            msg = "회원가입에 실패했습니다."
            msg_title = "회원가입"
            check = False
        print(check)

    elif type == 'findId':
        try:
            member = Member.objects.get(name = name)
        except Exception as e:
            print(e)
            msg = "본인인증에 실패했습니다."
            msg_title = "본인인증"
            check = False
        else:
            pass
    
    elif type == "changePw":
        try:
            member = Member.objects.get(name=name)
        except Exception as e:
            print(e)
            msg = "본인인증에 실패했습니다."
            msg_title = "본인인증"
            check = False
        else:
            pass            

    context = {
        "msg" : msg,
        "msg_title" : msg_title,
        "check" : check,
        "name" : name,
        "type" : type,

    }
    return render(request, 'member/certify/result.html', context)



def find(request:HttpRequest):
    type = request.GET.get('type')
    if type == 'changePw':
        id =request.POST.get("id")
        name =request.POST.get("name")
        try:
            member = Member.objects.get(email = id, name=name)
        except Exception as e1:
            print(e1)
            try:
                member = Member.objects.get(phone = id, name=name)
            except Exception as e2:
                print(e2) 
                return render(request, 'member/find/pwchange.html', {'check' : False})

    context = {
        'type' : type,
    }
    return render(request, 'member/find/form.html', context)

def findIdresult(request:HttpRequest):
    name = request.GET.get('name')
    msg = ""
    check = True
    try:
        member = Member.objects.get(name = name)
        msg = ""
    except Exception as e:
        msg = ""
        print(e)
    print(name)
    context = {
        'name' : name,
        'member' : member,
    }
    return render(request, 'member/find/idresult.html', context)

def findPwchange(request:HttpRequest):
    context = {
    }
    return render(request, 'member/find/pwchange.html', context)

def findPwresult(request:HttpRequest):
    name = request.GET.get('name')
    msg = ""
    check = True
    try:
        member = Member.objects.get(name = name)
        msg = ""
    except Exception as e:
        msg = ""
        print(e)
    print(name)
    context = {
        'name' : name,
        'member' : member,
    }
    return render(request, 'member/find/pwresult.html', context)

def findPwcomplite(request:HttpRequest):
    no = request.GET.get('no')
    pw = request.POST.get('pw')
    logout = request.POST.get('logout') #on/None
    # print(request.session('login'))
    msg = ''
    check = True
    try:
        member = Member.objects.get(member_no = no)
        member.password = pw
        member.save()
    except Exception as e:
        print(e)
        msg = '비밀번호 변경에 실패했습니다.'
        check = False
    else:
        if logout == 'on':
            # request.session.pop('login')
            pass
    context = {
        'msg' : msg,
        'check' : check,
        'member' : member,
    }
    return render(request, 'member/find/pwcomplite.html', context)

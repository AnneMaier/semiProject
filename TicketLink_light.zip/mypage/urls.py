from django.urls import path,include
from django.conf.urls.static import static
from . import views
from django.conf import settings

urlpatterns = [
    path('',views.index),
    path('reserve/',views.booking),
    path('discount/point/',views.point),
    path('discount/ticket/',views.ticket),
    path('discount/giftcard/',views.giftcard),
    path('discount/coupon/',views.coupon),
    # path('activity/event/',views.event),
    path('activity/review/',views.review),
    path('activity/fanclub/',views.fanclub),
    path('activity/waiting/list/',views.waiting),
    # path('document/diposit/',views.diposit),
    # path('document/cash/',views.cash),
    # path('document/creditCard/',views.creditCard),
    path('memberinfo/refundAccount/',views.refundAccount),
    path('memberinfo/account/',views.account),
    path('memberinfo/account/result/',views.accountResult),
    path('memberinfo/info/',views.memberinfo),
    path('memberinfo/withdrawal/',views.withdrawal),
    path('memberinfo/withdrawal/result/',views.withdrawalResult),
    path('memberinfo/re/',views.re),

]
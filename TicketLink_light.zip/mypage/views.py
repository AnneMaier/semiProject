from django.shortcuts import render, redirect
from django.http import HttpRequest,HttpResponse, JsonResponse

from TicketLink.models import Member, Agreement, Agree, Vip, Booking
from TicketLink.models import Perform, Write, BkCancel
from TicketLink.models import CancelTicket, Priorty, RefundAccount
from TicketLink.models import Bank

from datetime import date, datetime, timedelta
from django.core.paginator import Paginator
from dateutil.relativedelta import relativedelta

# Create your views here.


def index(request:HttpRequest):
    msg = ""
    point = 0
    check = True
    try:
        info = request.session.get('login')
        member = Member.objects.get(member_no = info)
        point = member.point
        if point == None:
            point = 0
        id = member.email
    except Exception as e:
        print(e)
        check = False
        msg = "로그인이 필요합니다"
    else:
        
        pass
        

    context = {
        'msg' : msg,
        'check' : check,
        'point' : point,
    }
    return render(request, 'mypage/layout/layout.html', context)

def booking(request:HttpRequest):
    msg = ""
    point = 0
    check = True
    booking = ''

    mode = request.GET.get("mode")
    if mode == None:
        mode = "bookTrue"
        mode_in = True
    elif mode == "bookTrue":
        mode_in = True
    elif mode == "bookFalse":
        mode_in = False
    now = datetime.now()
    period = request.GET.get("period")
    if period == None:
        period = 'month_1'
        before_n_month = now - relativedelta(months=1)
    elif period == 'month_1':
        before_n_month = now - relativedelta(months=1)
    elif period == 'month_2':
        before_n_month = now - relativedelta(months=2)
    elif period == 'month_3':
        before_n_month = now - relativedelta(months=3) 
    elif period == 'day_15':
        before_n_month = now - relativedelta(days=15) 
    print("현재:{} | {}: {}".format(now, period, before_n_month))

    types = request.GET.get("type")
    year = request.GET.get("year")
    month = request.GET.get("month")

    yearcnt = int(datetime.today().year)
    yearNow = str(yearcnt) + '년'
    yearOne = str(yearcnt-1) + '년'
    yearTwo = str(yearcnt-2) + '년'

    try:
        info = request.session.get('login')
        member = Member.objects.get(member_no = info)
        point = member.point
        if point == None:
            point = 0
        id = member.email
    except Exception as e:
        print(e)
        check = False
        msg = "로그인이 필요합니다"
    else:
        all = Booking.objects.filter(member_no = info)
        booking = Booking.objects.filter(member_no = info, bk_state = mode_in, bk_datetime__range=(before_n_month, now))
        bk_datetime__range=(before_n_month, now)



    MAX_PAGE_CNT = 10
    MAX_LIST_CNT = 5
    paginator = Paginator(booking,MAX_LIST_CNT)
    page = request.GET.get('page','1')
    page_obj = paginator.get_page(page)
    last_page = paginator.num_pages
    current_block = (int(page) - 1) // MAX_PAGE_CNT + 1
    start_page = (current_block - 1) * MAX_PAGE_CNT + 1
    end_page = start_page + MAX_PAGE_CNT -1        



    context = {
        'msg' : msg,
        'check' : check,
        'point' : point,
        'booking' : booking,
        'yearNow' : yearNow,
        'yearOne' : yearOne,
        'yearTwo' : yearTwo,
        "list" : page_obj,
        "last_page" : last_page,
        "start_page" : start_page,
        "end_page" : end_page,
        "mode" : mode,
        "period" : period,
        "type" : types,
        "year" : year,
        "month" : month,
        "before_n_month" : before_n_month,
        "now" : now,
    }
    return render(request, 'mypage/reserve/booking.html', context)




def point(request:HttpRequest):
    point = 0
    context = {
        "point" : point,
    }
    return render(request, 'mypage/discount/point.html', context)

def ticket(request:HttpRequest):
    point = 0
    TicketStatus = request.GET.get('TicketStatus')
    try:
       info = request.session.get('login')
       ticket = Member.objects.filter(member_no = info)
        
    except Exception as e:
        print(e)
    else:
        pass

    MAX_PAGE_CNT = 10
    MAX_LIST_CNT = 5
    paginator = Paginator(ticket,MAX_LIST_CNT)
    page = request.GET.get('page','1')
    page_obj = paginator.get_page(page)
    last_page = paginator.num_pages
    current_block = (int(page) - 1) // MAX_PAGE_CNT + 1
    start_page = (current_block - 1) * MAX_PAGE_CNT + 1
    end_page = start_page + MAX_PAGE_CNT -1   

    context = {
        "point" : point,
        # "ticket" : ticket,
        "list" : page_obj,
        "last_page" : last_page,
        "start_page" : start_page,
        "end_page" : end_page,
    }
    return render(request, 'mypage/discount/ticket.html', context)

def giftcard(request:HttpRequest):
    point = 0
    context = {
        "point" : point,
    }
    return render(request, 'mypage/discount/giftcard.html', context)

def coupon(request:HttpRequest):
    couponStatus = request.GET.get('couponStatus')
    print("쿠폰상태: {}".format(couponStatus))
    point = 0

    try:
       info = request.session.get('login')
       coupon = Member.objects.filter(member_no = info)
        
    except Exception as e:
        print(e)
    else:
        pass    

    MAX_PAGE_CNT = 10
    MAX_LIST_CNT = 5
    paginator = Paginator(coupon,MAX_LIST_CNT)
    page = request.GET.get('page','1')
    page_obj = paginator.get_page(page)
    last_page = paginator.num_pages
    current_block = (int(page) - 1) // MAX_PAGE_CNT + 1
    start_page = (current_block - 1) * MAX_PAGE_CNT + 1
    end_page = start_page + MAX_PAGE_CNT -1   
    context = {
        "point" : point,
        # "coupon" : coupon,
        "couponStatus" : couponStatus,
        "list" : page_obj,
        "last_page" : last_page,
        "start_page" : start_page,
        "end_page" : end_page,
    }
    return render(request, 'mypage/discount/coupon.html', context)

def review(request:HttpRequest):
    point = 0
    productClass = request.GET.get('productClass')
    info = request.session.get('login')
    try:
        write = Write.objects.filter(member_no = info)
    except Exception as e:
        print(e)
    MAX_PAGE_CNT = 10
    MAX_LIST_CNT = 5
    paginator = Paginator(write,MAX_LIST_CNT)
    page = request.GET.get('page','1')
    page_obj = paginator.get_page(page)
    last_page = paginator.num_pages
    current_block = (int(page) - 1) // MAX_PAGE_CNT + 1
    start_page = (current_block - 1) * MAX_PAGE_CNT + 1
    end_page = start_page + MAX_PAGE_CNT -1   

    context = {
        "point" : point,
        "productClass" : productClass,
        "write" : write,
        "list" : page_obj,
        "last_page" : last_page,
        "start_page" : start_page,
        "end_page" : end_page,
    }
    return render(request, 'mypage/activity/review.html', context)    

def fanclub(request:HttpRequest):
    point = 0    
    fanclub = []

    MAX_PAGE_CNT = 10
    MAX_LIST_CNT = 5
    paginator = Paginator(fanclub,MAX_LIST_CNT)
    page = request.GET.get('page','1')
    page_obj = paginator.get_page(page)
    last_page = paginator.num_pages
    current_block = (int(page) - 1) // MAX_PAGE_CNT + 1
    start_page = (current_block - 1) * MAX_PAGE_CNT + 1
    end_page = start_page + MAX_PAGE_CNT -1   

    context = {
        "point" : point,
        "list" : page_obj,
        "last_page" : last_page,
        "start_page" : start_page,
        "end_page" : end_page,
    }
    return render(request, 'mypage/activity/fanclub.html', context)    

def waiting(request:HttpRequest):
    point = 0    
    info = request.session.get('login')
    cancel = CancelTicket.objects.filter(member_no = info)
    cancelTicket_list = []
    for i in cancel:
        cancelTicket_list.append(i.no)
    priorty = Priorty.objects.filter(cct_no__in=cancelTicket_list)
    print(priorty.__len__())
    cnt = priorty.__len__()
    waiting = request.GET.get('waiting')
    monthVal = request.GET.get('monthVal')
    searchType = request.GET.get('searchType')
    subType = request.GET.get('subType')
    year = request.GET.get('searyearchType')
    month = request.GET.get('month')


    MAX_PAGE_CNT = 10
    MAX_LIST_CNT = 5
    paginator = Paginator(cancelTicket_list,MAX_LIST_CNT)
    page = request.GET.get('page','1')
    page_obj = paginator.get_page(page)
    last_page = paginator.num_pages
    current_block = (int(page) - 1) // MAX_PAGE_CNT + 1
    start_page = (current_block - 1) * MAX_PAGE_CNT + 1
    end_page = start_page + MAX_PAGE_CNT -1   
    context = {
        "point" : point,        
        "list" : page_obj,
        "last_page" : last_page,
        "start_page" : start_page,
        "end_page" : end_page,
        "waiting" : waiting,
        "monthVal" : monthVal,
        "searchType" : searchType,
        "subType" : subType,
        "year" : year,
        "month" : month,
        "cnt" : cnt,
        "cancel" : cancel, # 삭제고려
        "priorty" : priorty
        
    }
    return render(request, 'mypage/activity/waiting/list.html', context)       



def refundAccount(request:HttpRequest):
    point = 0
    try:
        info = request.session.get('login')
        account = RefundAccount.objects.get(member_no = info)
    except Exception as e:
        print(e)    
        account = "환불계좌를 등록하지 않았습니다"
    context = {
        "point" : point,
        "account" : account,
    }
    return render(request, 'mypage/memberinfo/refundAccount.html', context)

def account(request:HttpRequest):
    bank = Bank.objects.all()
    info = request.session.get("login")
    member = Member.objects.get(member_no = info)

    
    context = {
        "bank" : bank,
        "member" : member,
    }
    return render(request, 'mypage/memberinfo/account.html', context)

def accountResult(request:HttpRequest):
    msg = "Error"
    info = request.session.get("login")
    member = Member.objects.get(member_no = info)
    try:
        bank = request.POST.get('bank')
        rebank = Bank.objects.get(bank_name = bank)
        accountNum = request.POST.get('accountNum')
        account = RefundAccount.objects.get(member_no = info)
        account.bank_no = rebank
        account.account_num = accountNum
        account.save()
        msg = "계좌 등록에 성공했습니다."
    except Exception as e:
        print(e)
        msg = '계좌 등록에 실패했습니다.'
    
    context = {
        "msg" : msg,
    }
    return render(request, 'mypage/memberinfo/accountResult.html', context)


def memberinfo(request:HttpRequest):
    msg = ""
    point = 0
    check = True

    try:
        info = request.session.get('login')
        print(info)
        member = Member.objects.get(member_no = info)
        point = member.point
        if point == None:
            point = 0
        id = member.email
    except Exception as e:
        print(e)
        check = False
        msg = "로그인이 필요합니다"
        member = None
    else:
        print(check)
        

            
    context = {
        'msg' : msg,
        'check' : check,
        'point' : point,
        'member' : member,

    }
    return render(request, 'mypage/memberinfo/memberinfo.html', context)

def re(request:HttpRequest):
    email = request.POST.get('email')
    pw = request.POST.get('pw')
    phone = request.POST.get('phone')
    address = request.POST.get('address')  
    kind = request.POST.get('kind') 
    msg = "ERROR" 
    member = Member.objects.get(member_no = request.session.get('login')) 
    try:
        member.email = email
        member.password = pw
        member.phone = phone
        member.address = address
        if kind == "custom": 
            member.kind = 2
        elif kind == "admin":
            member.kind = 1
        member.save()
        request.session['login_email'] = member.email
    except Exception as e:
        print(e)
        msg = "회원 정보 수정에 실패했습니다" 
    else:
        msg = "회원 정보 수정에 성공했습니다."
        request.session['login_kind'] = member.kind
        request.session['login_email'] = member.email


    context = {
        'email' : email,
        'pw' : pw,
        'phone' : phone,
        'address' : address,
        'msg' : msg,
    }
    return render(request, 'mypage/memberinfo/re.html', context)    


def withdrawal(request:HttpRequest):
    point = 0
    check = None
    try:
        check = request.GET.get("check")
    except Exception as e:
        print(e)
    context = {
        'point' : point,
        'check' : check,
        
    }
    return render(request, 'mypage/memberinfo/withdrawal.html', context)

def withdrawalResult(request:HttpRequest):
    msg = "Error"
    info = request.session.get("login")
    member = Member.objects.get(member_no = info)
    try:
        member.delete()
        request.session.clear()
    except Exception as e:
        print(e)
        msg = "탈퇴에 실패하였습니다."
    else:
        msg = "탈퇴 되었습니다"

    context = {
        'msg' : msg,
    }
    return render(request, 'mypage/memberinfo/withdrawalResult.html', context)

from django.urls import path,include
from django.conf.urls.static import static
from . import views
from django.conf import settings

urlpatterns = [
    path('',views.index),
    path('genre/musical/',views.musical),
    path('genre/theater/',views.theater),
    path('genre/concert/',views.concert),
    path('genre/classic/',views.classic),
    path('genre/deahakro/',views.deahakro),
    path('genre/family/',views.family),
    path('genre/theater/',views.theater),
    path('exhibition/home',views.exhibitionHome),
    path('exhibition/exhibition',views.exhibition),
    path('exhibition/leisure',views.leisure),
    path('ranking/', views.ranking),
    path('region/home/',views.regionhome),
    path('region/gyeonggi/',views.gyeonggi),
    path('region/chungcheong/',views.chungcheong),
    path('region/deagu/',views.deagu),
    path('region/busan/',views.busan),
    path('region/gwangju/',views.gwangju),
    path('region/jeju/',views.jeju),
    path('place/',views.place),
    path('product/',views.product),
    path('product/dateRound/',views.dateRound),
    path('product/chooseAjax/',views.chooseAjax),
    path('rolelist/',views.rolelist),
    path('rolelist_Ajax/',views.rolelistAjax),
    path('product/writeCheck/',views.writeCheck),
    path('booking/schedule/',views.bkSchedule),
    path('booking/schedule/date_Ajax/',views.dateAjax),
    path('booking/schedule/pfr_Ajax/',views.pfrAjax),
    path('booking/seat/',views.bkSeat),
    path('booking/ticket/',views.bkTicket),
    path('booking/ticket_Ajax/',views.ticketAjax),
    path('booking/delivery/',views.bkDelivery),
    path('booking/complete/',views.bkComplete),
    path('booking_2/ticket/',views.bkTicket2),
    path('booking/ticket_Ajax2/',views.ticketAjax2),
    path('booking/delivery_2/',views.bkDelivery2),
    path('booking/delivery_2/',views.bkDelivery2),
    path('waiting/selectseat/',views.wtSelectSeat),
    path('waiting/complete/',views.wtComplete),
    path('canceling/check/',views.ccCheck),
    path('canceling/complete',views.ccComplete),
    path('pwCheck/',views.pwCheck),
    path('priorty/check/',views.prCheck)




]

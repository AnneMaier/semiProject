from django.shortcuts import render, redirect
from django.http import HttpRequest,HttpResponse, JsonResponse
from TicketLink.models import Member, Role, Perform, PerformRound, PerformCharge0, SeatType, Role, PerformRound, Promotion, Write , Place, Seat, CancelType, Genre, RecieveWay, Booking, PerformCharge1, CancelTicket, Bank, BkCancel, Priorty
import random, json, re
from datetime import datetime, timedelta

# Create your views here.
def index(request:HttpRequest):


    pf_no = request.GET.get('pf_no')
    gr_no= request.GET.get('gr_no')


    perform_all = Perform.objects.all()
    perform_all_su= 0
    perform_recommend = []
    perform_recommend_su = []

    perform = Perform.objects.filter(perform_no=pf_no)
    genre = Genre.objects.filter(genre_no = gr_no)

    for i in perform_all:

        perform_all_su+=1

    while perform_recommend.__len__() < 5:
        perform_rannum = random.randint(1,perform_all_su)
        if perform_rannum in perform_recommend_su:
            continue
        else:
            perform_recommend.append(Perform.objects.get(perform_no=perform_rannum))
            perform_recommend_su.append(perform_rannum)

 
    context={

        "perform_all" : perform_all,
        "recommend" : perform_recommend,
        "perform" : perform,
        "genre" : genre,

    }

    return render(request, 'perform/index.html',context)

def musical(request:HttpRequest):

    # ---------------------------------뮤지컬--------------------------------
    test = []

    for i in Genre.objects.filter(gnr_name='뮤지컬'):
        test.append(i.genre_no)
    print(test)

    musical_all = Perform.objects.filter(genre_no__in=test)
    print(musical_all)

    musical_all_su = 0

    musical_recommend = []
    musical_recommend_su = []

    for i in musical_all:
        musical_all_su +=1
        # print('메롱')
    while musical_recommend.__len__() <3:
        musical_rannum = random.randint(1,musical_all_su)
        if musical_rannum in musical_recommend_su:
            continue
        else:
            musical_recommend.append(Perform.objects.get(perform_no=musical_rannum))
            musical_recommend_su.append(musical_rannum)




   
    seoul=[]
    gyeonggi=[]
    chungcheong=[]
    deagu=[]
    busan=[]
    gwangju=[]
    jeju=[]

    genre_musical = [1,2]


    for i in Place.objects.filter(region_no=1):
        seoul.append(i.place_no)
    print(seoul)
    musi_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_musical)
    print(musi_seoul)
            
    for i in Place.objects.filter(region_no=2):
        gyeonggi.append(i.place_no)
    musi_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_musical)


    for i in Place.objects.filter(region_no=3):
        chungcheong.append(i.place_no)
    musi_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_musical)


    for i in Place.objects.filter(region_no=4):
        deagu.append(i.place_no)
    musi_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_musical)


    for i in Place.objects.filter(region_no=5):
        busan.append(i.place_no)
    musi_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_musical)


    for i in Place.objects.filter(region_no=6):
        gwangju.append(i.place_no)
    musi_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_musical)


    for i in Place.objects.filter(region_no=7):
        jeju.append(i.place_no)
    musi_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_musical)

    context = {

        "musical_all" : musical_all,
        "musical_recommend": musical_recommend,
        "musi_seoul" : musi_seoul,
        "musi_gyeonggi" : musi_gyeonggi,
        "musi_chungcheong" : musi_chungcheong,
        "musi_deagu" : musi_deagu,
        "musi_busan" : musi_busan,
        "musi_gwangju" : musi_gwangju,
        "musi_jeju" : musi_jeju,

    }
      
    return render(request, 'perform/genre/musical.html', context)


def theater(request:HttpRequest):
    # ---------------------------------연극-----------------------------------------
    test2 = []
    genre_theater = [3,4]

    seoul=[]
    gyeonggi=[]
    chungcheong=[]
    deagu=[]
    busan=[]
    gwangju=[]
    jeju=[]


    for j in Genre.objects.filter(gnr_name='연극'):
        test2.append(j.genre_no)
    print(test2)

    theater_all = Perform.objects.filter(genre_no__in=test2)
    print(theater_all)

    theater_all_su = 0
    
    theater_recommend = []
    theater_recommend_su = []
    

    for o in theater_all:
        theater_all_su +=1
    while theater_recommend.__len__() <3:
        theater_rannum = random.randint(1,theater_all_su)
        if theater_rannum in theater_recommend_su:
            continue
        else:
            theater_recommend = (Perform.objects.filter(genre_no__in=genre_theater))
            theater_recommend_su.append(theater_rannum)

    print(theater_recommend_su)
    print(theater_recommend)


    for i in Place.objects.filter(region_no=1):
        seoul.append(i.place_no)
    print(seoul)
    thea_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_theater)
    print(thea_seoul)

    for i in Place.objects.filter(region_no=2):
        gyeonggi.append(i.place_no)
    print(gyeonggi)
    thea_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_theater)
    print(thea_gyeonggi)

    for i in Place.objects.filter(region_no=3):
        chungcheong.append(i.place_no)
    thea_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_theater)
    print(thea_chungcheong)

    for i in Place.objects.filter(region_no=4):
        deagu.append(i.place_no)
    print(deagu)
    thea_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_theater)
    print(thea_deagu)

    for i in Place.objects.filter(region_no=5):
        busan.append(i.place_no)
    print(busan)
    thea_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_theater)
    print(thea_busan)

    for i in Place.objects.filter(region_no=6):
        gwangju.append(i.place_no)
    print(gwangju)
    thea_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_theater)
    print(thea_gwangju)

    for i in Place.objects.filter(region_no=7):
        jeju.append(i.place_no)
    print(jeju)
    thea_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_theater)
    print(thea_jeju)

    context = {
        "theater_all" : theater_all,
        "theater_recommend" : theater_recommend,
        "thea_seoul" : thea_seoul,
        "thea_gyeonggi" : thea_gyeonggi,
        "thea_chungcheong" : thea_chungcheong,
        "thea_deagu" : thea_deagu,
        "thea_busan" : thea_busan,
        "thea_gwangju" : thea_gwangju,
        "thea_jeju" : thea_jeju,
    }

    
    return render(request, 'perform/genre/theater.html', context)

def concert(request:HttpRequest):

    #     # ----------------------------------콘서트-------------------------------------------

    test3 = []
    genre_concert = [5,6]

    for i in Genre.objects.filter(gnr_name='콘서트'):
        test3.append(i.genre_no)
    print(test3)
    concert_all = Perform.objects.filter(genre_no__in=test3)
    print(concert_all)
    concert_all_su = 0

    concert_recommend = []
    concert_recommend_su = []
    

    for p in concert_all:
        concert_all_su +=1

    while concert_recommend.__len__() <3:
        concert_rannum = random.randint(1,concert_all_su)
        if concert_rannum in concert_recommend_su:
            continue
        else:
            concert_recommend = (Perform.objects.filter(genre_no__in = genre_concert))
            concert_recommend_su.append(concert_rannum)


    seoul=[]
    gyeonggi=[]
    chungcheong=[]
    deagu=[]
    busan=[]
    gwangju=[]
    jeju=[]



    for i in Place.objects.filter(region_no=1):
        seoul.append(i.place_no)
    concert_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_concert)
    print(concert_seoul)

    for i in Place.objects.filter(region_no=2):
        gyeonggi.append(i.place_no)
    concert_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_concert)
    print(concert_gyeonggi)

    for i in Place.objects.filter(region_no=3):
        chungcheong.append(i.place_no)
    concert_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_concert)
    print(concert_chungcheong)

    for i in Place.objects.filter(region_no=4):
        deagu.append(i.place_no)
    concert_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_concert)
    print(concert_deagu)

    for i in Place.objects.filter(region_no=5):
        busan.append(i.place_no)
    concert_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_concert)
    print(concert_busan)

    for i in Place.objects.filter(region_no=6):
        gwangju.append(i.place_no)
    concert_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_concert)
    print(concert_gwangju)

    for i in Place.objects.filter(region_no=7):
        jeju.append(i.place_no)
    concert_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_concert)
    print(concert_jeju)

    context = {
        "concert_all" : concert_all,
        "concert_recommend" : concert_recommend,
        "concert_seoul" : concert_seoul,
        "concert_gyeonggi" : concert_gyeonggi,
        "concert_chungcheong" : concert_chungcheong,
        "concert_deagu" : concert_deagu,
        "concert_busan" : concert_busan,
        "concert_gwangju" : concert_gwangju,
        "concert_jeju" : concert_jeju,


    }


    return render(request, 'perform/genre/concert.html', context)

def classic(request:HttpRequest):

    # # -----------------------------------------클래식/무용--------------------------------

    test4 = []
    genre_classic = [7,8]

    for i in Genre.objects.filter(gnr_name='클래식/무용'):
        test4.append(i.genre_no)
    print(test4)
    classic_all = Perform.objects.filter(genre_no__in=test4)
    print(classic_all)
    classic_all_su = 0
    
    classic_recommend = []
    classic_recommend_su = []
    

    for o in classic_all:
        classic_all_su +=1
   
    while classic_recommend.__len__() <3:
        classic_rannum = random.randint(1,classic_all_su)
        if classic_rannum in classic_recommend_su:
            continue
        else:
            classic_recommend=(Perform.objects.filter(genre_no__in = genre_classic))
            classic_recommend_su.append(classic_rannum)

    
    seoul=[]
    gyeonggi=[]
    chungcheong=[]
    deagu=[]
    busan=[]
    gwangju=[]
    jeju=[]



    for i in Place.objects.filter(region_no=1):
        seoul.append(i.place_no)
    classic_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_classic)
    print(classic_seoul)

    for i in Place.objects.filter(region_no=2):
        gyeonggi.append(i.place_no)
    classic_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_classic)
    print(classic_gyeonggi)

    for i in Place.objects.filter(region_no=3):
        chungcheong.append(i.place_no)
    classic_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_classic)
    print(classic_chungcheong)

    for i in Place.objects.filter(region_no=4):
        deagu.append(i.place_no)
    classic_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_classic)
    print(classic_deagu)

    for i in Place.objects.filter(region_no=5):
        busan.append(i.place_no)
    classic_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_classic)
    print(classic_busan)

    for i in Place.objects.filter(region_no=6):
        gwangju.append(i.place_no)
    classic_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_classic)
    print(classic_gwangju)

    for i in Place.objects.filter(region_no=7):
        jeju.append(i.place_no)
    classic_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_classic)
    print(classic_jeju)


    context={
        
        "classic_all" : classic_all,
        "classic_recommend" : classic_recommend,
        "classic_seoul" : classic_seoul,
        "classic_gyeonggi" : classic_gyeonggi,
        "classic_chungcheong" : classic_chungcheong,
        "classic_deagu" : classic_deagu,
        "classic_busan" : classic_busan,
        "classic_gwangju" : classic_gwangju,
        "classic_jeju" : classic_jeju,
    }


    return render(request, 'perform/genre/classic.html', context)

def deahakro(request:HttpRequest):

    test6 = []
    genre_deahakro = [1,2,3,4,5,6]

    seoul=[]


    for j in Genre.objects.filter(genre_no__in = genre_deahakro):
        test6.append(j.genre_no)
    print(test6)

    deahakro_all = Perform.objects.filter(genre_no__in=test6)
    print(deahakro_all)

    deahakro_all_su = 0
    
    deahakro_recommend = []
    deahakro_recommend_su = []
    

    for o in deahakro_all:
        deahakro_all_su +=1
    while deahakro_recommend.__len__() <3:
        deahakro_rannum = random.randint(1,deahakro_all_su)
        if deahakro_rannum in deahakro_recommend_su:
            continue
        else:
            deahakro_recommend = (Perform.objects.filter(genre_no__in=genre_deahakro))
            deahakro_recommend_su.append(deahakro_rannum)


    for i in Place.objects.filter(region_no=1):
        seoul.append(i.place_no)
    print(seoul)
    deahakro_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_deahakro)
    print(deahakro_seoul)


    context ={
        "deahakro_all" : deahakro_all,
        "deahakro_recommend" : deahakro_recommend,
        "deahakro_seoul" : deahakro_seoul,
    }

    
    return render(request, 'perform/genre/deahakro.html', context)

def family(request:HttpRequest):
#  # -----------------------------------------아동/가족--------------------------------

    test5 = []
    genre_family = [7]

    for i in Genre.objects.filter(gnr_name='아동/가족'):
        test5.append(i.genre_no)
    print(test5)
    family_all = Perform.objects.filter(genre_no__in=test5)
    print(family_all)
    family_all_su = 0
    
    family_recommend = []
    family_recommend_su = []
    

    for o in family_all:
        family_all_su +=1
  
    while family_recommend.__len__() <3:
        family_rannum = random.randint(1,family_all_su)
        if family_rannum in family_recommend_su:
            continue
        else:
            family_recommend = (Perform.objects.filter(genre_no__in = genre_family))
            family_recommend_su.append(family_rannum)

       
    seoul=[]
    gyeonggi=[]
    chungcheong=[]
    deagu=[]
    busan=[]
    gwangju=[]
    jeju=[]



    for i in Place.objects.filter(region_no=1):
        seoul.append(i.place_no)
    family_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_family)
    print(family_seoul)

    for i in Place.objects.filter(region_no=2):
        gyeonggi.append(i.place_no)
    family_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_family)
    print(family_gyeonggi)

    for i in Place.objects.filter(region_no=3):
        chungcheong.append(i.place_no)
    family_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_family)
    print(family_chungcheong)

    for i in Place.objects.filter(region_no=4):
        deagu.append(i.place_no)
    family_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_family)
    print(family_deagu)

    for i in Place.objects.filter(region_no=5):
        busan.append(i.place_no)
    family_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_family)
    print(family_busan)

    for i in Place.objects.filter(region_no=6):
        gwangju.append(i.place_no)
    family_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_family)
    print(family_gwangju)

    for i in Place.objects.filter(region_no=7):
        jeju.append(i.place_no)
    family_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_family)
    print(family_jeju)





    context = {

        "family_all" : family_all,
        "family_recommend" : family_recommend,
        "family_seoul" : family_seoul,
        "family_gyeonggi" : family_gyeonggi,
        "family_chungcheong" : family_chungcheong,
        "family_deagu" : family_deagu,
        "family_busan" : family_busan,
        "family_gwangju" : family_gwangju,
        "family_jeju" : family_jeju,

    }


    return render(request, 'perform/genre/family.html', context)



def exhibitionHome(request:HttpRequest):

    test12 = []
    genre_exhibition = [11,12,13,14]



    for j in Genre.objects.filter(genre_no__in=genre_exhibition):
        test12.append(j.genre_no)
    print(test12)

    exhibition_all = Perform.objects.filter(genre_no__in=test12)
    print(exhibition_all)

    # exhi_all_su = 0
    
    # exhi_recommend = []
    # exhi_recommend_su = []
    

    # for o in exhi_all:
    #     exhi_all_su +=1
    # while exhi_recommend.__len__() <3:
    #     exhi_rannum = random.randint(1,exhi_all_su)
    #     if exhi_rannum in exhi_recommend_su:
    #         continue
    #     else:
    #         exhi_recommend = (Perform.objects.filter(genre_no__in=genre_exhi))
    #         exhi_recommend_su.append(exhi_rannum)


    context={
        "exhibition_all" : exhibition_all,
    }


    return render(request, 'perform/exhibition/home.html', context)



def exhibition(request: HttpRequest):
    test10 = []
    genre_exhi = [11,12]



    for j in Genre.objects.filter(gnr_name='전시/축제'):
        test10.append(j.genre_no)
    print(test10)

    exhi_all = Perform.objects.filter(genre_no__in=test10)
    print(exhi_all)

    # exhi_all_su = 0
    
    # exhi_recommend = []
    # exhi_recommend_su = []
    

    # for o in exhi_all:
    #     exhi_all_su +=1
    # while exhi_recommend.__len__() <3:
    #     exhi_rannum = random.randint(1,exhi_all_su)
    #     if exhi_rannum in exhi_recommend_su:
    #         continue
    #     else:
    #         exhi_recommend = (Perform.objects.filter(genre_no__in=genre_exhi))
    #         exhi_recommend_su.append(exhi_rannum)
    seoul=[]
    gyeonggi=[]
    chungcheong=[]
    deagu=[]
    busan=[]
    gwangju=[]
    jeju=[]

    for i in Place.objects.filter(region_no=1):
        seoul.append(i.place_no)
    exhi_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_exhi)
    print(exhi_seoul)

    for i in Place.objects.filter(region_no=2):
        gyeonggi.append(i.place_no)
    exhi_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_exhi)
    print(exhi_gyeonggi)

    for i in Place.objects.filter(region_no=3):
        chungcheong.append(i.place_no)
    exhi_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_exhi)
    print(exhi_chungcheong)

    for i in Place.objects.filter(region_no=4):
        deagu.append(i.place_no)
    exhi_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_exhi)
    print(exhi_deagu)

    for i in Place.objects.filter(region_no=5):
        busan.append(i.place_no)
    exhi_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_exhi)
    print(exhi_busan)

    for i in Place.objects.filter(region_no=6):
        gwangju.append(i.place_no)
    exhi_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_exhi)
    print(exhi_gwangju)

    for i in Place.objects.filter(region_no=7):
        jeju.append(i.place_no)
    exhi_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_exhi)
    print(exhi_jeju)

    context={

        "exhi_all" : exhi_all,
        "exhi_seoul" : exhi_seoul,
        "exhi_gyeonggi" : exhi_gyeonggi,
        "exhi_chungcheong" : exhi_chungcheong,
        "exhi_deagu" : exhi_deagu,
        "exhi_busan" : exhi_busan,
        "exhi_gwangju" : exhi_gwangju,
        "exhi_jeju" : exhi_jeju,

    }

    return render(request, 'perform/exhibition/exhibition.html', context)



def leisure(request: HttpRequest):

    test11 = []
    genre_leisure = [13,14]


    for j in Genre.objects.filter(gnr_name='레저/체험'):
        test11.append(j.genre_no)
    print(test11)

    leisure_all = Perform.objects.filter(genre_no__in=test11)
    print(leisure_all)

    # leisure_all_su = 0
    
    # leisure_recommend = []
    # leisure_recommend_su = []
    

    # for o in leisure_all:
    #     leisure_all_su +=1
    # while leisure_recommend.__len__() <3:
    #     leisure_rannum = random.randint(1,leisure_all_su)
    #     if leisure_rannum in leisure_recommend_su:
    #         continue
    #     else:
    #         leisure_recommend = (Perform.objects.filter(genre_no__in=genre_leisure))
    #         leisure_recommend_su.append(leisure_rannum)

    seoul=[]
    gyeonggi=[]
    chungcheong=[]
    deagu=[]
    busan=[]
    gwangju=[]
    jeju=[]


    for i in Place.objects.filter(region_no=1):
        seoul.append(i.place_no)
    leisure_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_leisure)
    print(leisure_seoul)

    for i in Place.objects.filter(region_no=2):
        gyeonggi.append(i.place_no)
    leisure_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_leisure)
    print(leisure_gyeonggi)

    for i in Place.objects.filter(region_no=3):
        chungcheong.append(i.place_no)
    leisure_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_leisure)
    print(leisure_chungcheong)

    for i in Place.objects.filter(region_no=4):
        deagu.append(i.place_no)
    leisure_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_leisure)
    print(leisure_deagu)

    for i in Place.objects.filter(region_no=5):
        busan.append(i.place_no)
    leisure_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_leisure)
    print(leisure_busan)

    for i in Place.objects.filter(region_no=6):
        gwangju.append(i.place_no)
    leisure_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_leisure)
    print(leisure_gwangju)

    for i in Place.objects.filter(region_no=7):
        jeju.append(i.place_no)
    leisure_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_leisure)
    print(leisure_jeju)

    
    context={
        "leisure_all" : leisure_all,
        # "leisure_recommend" : leisure_recommend,
        "leisure_gyeonggi" : leisure_gyeonggi,
        "leisure_chungcheong" : leisure_chungcheong,
        "leisure_deagu" : leisure_deagu,
        "leisure_busan" : leisure_busan,
        "leisure_gwangju" : leisure_gwangju,
        "leisure_jeju" : leisure_jeju,
    }


    return render(request, 'perform/exhibition/leisure.html', context)



def ranking(request:HttpRequest):
    return render(request, 'perform/ranking.html')


def place(request:HttpRequest):
    return render(request, 'perform/place.html')

def regionhome(request: HttpRequest):

    seoul=[]
    genre_musical = [1,2]
    genre_theater = [3,4]
    genre_concert = [5,6]
    genre_classic = [7,8]
    genre_family = [10]
    genre_exhi = [11,12]
    genre_leisure = [13,14]

    for i in Place.objects.filter(region_no=1):
        seoul.append(i.place_no)
    print(seoul)
    seoul_all = Perform.objects.filter(place_no__in=seoul)
    musi_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_musical)
    print(musi_seoul)
    thea_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_theater)
    print(thea_seoul)

    concert_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_concert)
    print(concert_seoul)

    classic_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_classic)
    print(classic_seoul)

    family_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_family)
    print(family_seoul)

    exhi_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_exhi)
    print(exhi_seoul)

    leisure_seoul = Perform.objects.filter(place_no__in=seoul, genre_no__in=genre_leisure)
    print(leisure_seoul)



    context={
        "seoul_all" : seoul_all,
        "musi_seoul" : musi_seoul,
        "thea_seoul" : thea_seoul,
        "concert_seoul" : concert_seoul,
        "classic_seoul" : classic_seoul,
        "family_seoul" : family_seoul,
        "exhi_seoul" : exhi_seoul,
        "leisure_seoul" : leisure_seoul

        

    }

    return render(request, 'perform/region/home.html', context)

def gyeonggi(request: HttpRequest):

    gyeonggi = []

    genre_musical = [1,2]
    genre_theater = [3,4]
    genre_concert = [5,6]
    genre_classic = [7,8]
    genre_family = [10]
    genre_exhi = [11,12]
    genre_leisure = [13,14]

    for i in Place.objects.filter(region_no=2):
        gyeonggi.append(i.place_no)
    print(gyeonggi)
    gyeonggi_all = Perform.objects.filter(place_no__in=gyeonggi)
    musi_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_musical)
    print(musi_gyeonggi)
    thea_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_theater)
    print(thea_gyeonggi)

    concert_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_concert)
    print(concert_gyeonggi)

    classic_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_classic)
    print(classic_gyeonggi)

    family_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_family)
    print(family_gyeonggi)

    exhi_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_exhi)
    print(exhi_gyeonggi)

    leisure_gyeonggi = Perform.objects.filter(place_no__in=gyeonggi, genre_no__in=genre_leisure)
    print(leisure_gyeonggi)



    context={
        "gyeonggi_all" : gyeonggi_all,
        "musi_gyeonggi" : musi_gyeonggi,
        "thea_gyeonggi" : thea_gyeonggi,
        "concert_gyeonggi" : concert_gyeonggi,
        "classic_gyeonggi" : classic_gyeonggi,
        "family_gyeonggi" : family_gyeonggi,
        "exhi_gyeonggi" : exhi_gyeonggi,
        "leisure_gyeonggi" : leisure_gyeonggi

    }
    return render(request, 'perform/region/gyeonggi.html', context)

def chungcheong(request: HttpRequest):

    chungcheong=[]

    genre_musical = [1,2]
    genre_theater = [3,4]
    genre_concert = [5,6]
    genre_classic = [7,8]
    genre_family = [10]
    genre_exhi = [11,12]
    genre_leisure = [13,14]

    for i in Place.objects.filter(region_no=3):
        chungcheong.append(i.place_no)
    print(chungcheong)
    chungcheong_all = Perform.objects.filter(place_no__in=chungcheong)
    musi_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_musical)
    print(musi_chungcheong)
    thea_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_theater)
    print(thea_chungcheong)

    concert_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_concert)
    print(concert_chungcheong)

    classic_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_classic)
    print(classic_chungcheong)

    family_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_family)
    print(family_chungcheong)

    exhi_chungcheong = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_exhi)
    print(exhi_chungcheong)

    leisure_gyeonggi = Perform.objects.filter(place_no__in=chungcheong, genre_no__in=genre_leisure)
    print(leisure_gyeonggi)



    context={
        "chungcheong_all" : chungcheong_all,
        "musi_chungcheong" : musi_chungcheong,
        "thea_chungcheong" : thea_chungcheong,
        "concert_chungcheong" : concert_chungcheong,
        "classic_chungcheong" : classic_chungcheong,
        "family_chungcheong" : family_chungcheong,
        "exhi_chungcheong" : exhi_chungcheong,
        "leisure_chungcheong" : leisure_gyeonggi

    }
    return render(request, 'perform/region/chungcheong.html',context)

def deagu(request: HttpRequest):

    
    deagu=[]

    genre_musical = [1,2]
    genre_theater = [3,4]
    genre_concert = [5,6]
    genre_classic = [7,8]
    genre_family = [10]
    genre_exhi = [11,12]
    genre_leisure = [13,14]

    for i in Place.objects.filter(region_no=4):
        deagu.append(i.place_no)
    print(deagu)
    deagu_all = Perform.objects.filter(place_no__in=deagu)
    musi_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_musical)
    print(musi_deagu)
    thea_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_theater)
    print(thea_deagu)

    concert_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_concert)
    print(concert_deagu)

    classic_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_classic)
    print(classic_deagu)

    family_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_family)
    print(family_deagu)

    exhi_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_exhi)
    print(exhi_deagu)

    leisure_deagu = Perform.objects.filter(place_no__in=deagu, genre_no__in=genre_leisure)
    print(leisure_deagu)



    context={
        "deagu_all" : deagu_all,
        "musi_deagu" : musi_deagu,
        "thea_deagu" : thea_deagu,
        "concert_deagu" : concert_deagu,
        "classic_deagu" : classic_deagu,
        "family_deagu" : family_deagu,
        "exhi_deagu" : exhi_deagu,
        "leisure_deagu" : leisure_deagu

    }

    return render(request, 'perform/region/deagu.html', context)

def busan(request: HttpRequest):

       
    busan=[]

    genre_musical = [1,2]
    genre_theater = [3,4]
    genre_concert = [5,6]
    genre_classic = [7,8]
    genre_family = [10]
    genre_exhi = [11,12]
    genre_leisure = [13,14]

    for i in Place.objects.filter(region_no=5):
        busan.append(i.place_no)
    print(busan)
    busan_all = Perform.objects.filter(place_no__in=busan)
    musi_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_musical)
    print(musi_busan)
    thea_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_theater)
    print(thea_busan)

    concert_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_concert)
    print(concert_busan)

    classic_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_classic)
    print(classic_busan)

    family_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_family)
    print(family_busan)

    exhi_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_exhi)
    print(exhi_busan)

    leisure_busan = Perform.objects.filter(place_no__in=busan, genre_no__in=genre_leisure)
    print(leisure_busan)



    context={
        "busan_all" : busan_all,
        "musi_busan" : musi_busan,
        "thea_busan" : thea_busan,
        "concert_busan" : concert_busan,
        "classic_busan" : classic_busan,
        "family_busan" : family_busan,
        "exhi_busan" : exhi_busan,
        "leisure_busan" : leisure_busan

    }
    return render(request, 'perform/region/busan.html', context)

def gwangju(request: HttpRequest):

           
    gwangju=[]

    genre_musical = [1,2]
    genre_theater = [3,4]
    genre_concert = [5,6]
    genre_classic = [7,8]
    genre_family = [10]
    genre_exhi = [11,12]
    genre_leisure = [13,14]

    for i in Place.objects.filter(region_no=6):
        gwangju.append(i.place_no)
    print(gwangju)
    gwangju_all = Perform.objects.filter(place_no__in=gwangju)
    musi_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_musical)
    print(musi_gwangju)
    thea_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_theater)
    print(thea_gwangju)

    concert_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_concert)
    print(concert_gwangju)

    classic_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_classic)
    print(classic_gwangju)

    family_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_family)
    print(family_gwangju)

    exhi_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_exhi)
    print(exhi_gwangju)

    leisure_gwangju = Perform.objects.filter(place_no__in=gwangju, genre_no__in=genre_leisure)
    print(leisure_gwangju)



    context={
        "gwangju_all" : gwangju_all,
        "musi_gwangju" : musi_gwangju,
        "thea_gwangju" : thea_gwangju,
        "concert_gwangju" : concert_gwangju,
        "classic_gwangju" : classic_gwangju,
        "family_gwangju" : family_gwangju,
        "exhi_gwangju" : exhi_gwangju,
        "leisure_gwangju" : leisure_gwangju

    }


    return render(request, 'perform/region/gwangju.html', context)

def jeju(request: HttpRequest):

       
    jeju=[]

    genre_musical = [1,2]
    genre_theater = [3,4]
    genre_concert = [5,6]
    genre_classic = [7,8]
    genre_family = [10]
    genre_exhi = [11,12]
    genre_leisure = [13,14]

    for i in Place.objects.filter(region_no=7):
        jeju.append(i.place_no)
    print(jeju)
    jeju_all = Perform.objects.filter(place_no__in=jeju)
    musi_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_musical)
    print(musi_jeju)
    thea_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_theater)
    print(thea_jeju)

    concert_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_concert)
    print(concert_jeju)

    classic_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_classic)
    print(classic_jeju)

    family_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_family)
    print(family_jeju)

    exhi_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_exhi)
    print(exhi_jeju)

    leisure_jeju = Perform.objects.filter(place_no__in=jeju, genre_no__in=genre_leisure)
    print(leisure_jeju)



    context={
        "jeju_all" : jeju_all,
        "musi_jeju" : musi_jeju,
        "thea_jeju" : thea_jeju,
        "concert_jeju" : concert_jeju,
        "classic_jeju" : classic_jeju,
        "family_jeju" : family_jeju,
        "exhi_jeju" : exhi_jeju,
        "leisure_jeju" : leisure_jeju

    }

    return render(request, 'perform/region/jeju.html', context)















def product(request:HttpRequest):
    pf_no = request.GET.get('pf_no')
    perform_all = Perform.objects.all()
    perform_all_su= 0
    perform_recommend = []
    perform_recommend_su = []
    for i in perform_all:
        perform_all_su+=1
    while perform_recommend.__len__() < 5:
        perform_rannum = random.randint(1,perform_all_su)
        if perform_rannum in perform_recommend_su:
            continue
        else:
            perform_recommend.append(Perform.objects.get(perform_no=perform_all[perform_rannum-1].perform_no))
            perform_recommend_su.append(perform_rannum)
    


    perform = Perform.objects.filter(perform_no=pf_no)
    roles = Role.objects.filter(perform_no=pf_no).order_by('role_no')

    seat = SeatType.objects.filter(perform_no=pf_no)
    sale = PerformCharge0.objects.filter(perform_no=pf_no)
    pc1 = PerformCharge1.objects.filter(perform_no=pf_no)
    perform_round = PerformRound.objects.filter(perform_no = pf_no)
    # promo = Promotion.objects.filter(perform_no=pf_no)
    reviews = Write.objects.filter(perform_no=pf_no, writetype_no=1)
    review_su = 0
    exceptations = Write.objects.filter(perform_no=pf_no, writetype_no=2)
    exceptations_su = 0
    score_full = 0
    for i in reviews:
        review_su+=1
        score_full += i.score

    if review_su != 0:
        
        score_average = round((score_full / review_su),1)
    else:
         score_average = 0
    
    for i in exceptations:
        exceptations_su +=1


    context= {
        "perform_all" : perform_all,
        "recommend" : perform_recommend,
        "perform" : perform,
        "rolelist" : roles,
        "pf_no" : pf_no,
        "seat" : seat,
        "sale" : sale,
        "perform_rounds" : perform_round,
        # "promo" : promo,
        "reviews" : reviews,
        "review_su" : review_su,
        "score_average" : score_average,
        "exceptations" : exceptations,
        "exceptations_su" : exceptations_su,
        "pc1" : pc1

    


    }
    
    return render(request, 'perform/product.html', context)

    


def rolelist(request:HttpRequest):
    round_actor_list = []
    
 
    pf_no = request.GET.get('pf_no')
    perform_selected = Perform.objects.filter(perform_no = pf_no)
    perform_round = PerformRound.objects.filter(perform_no = pf_no)
    
    roles = Role.objects.filter(perform_no=pf_no).order_by('role_no')
    for i in perform_round:
        pfr_role_list = eval(i.pfr_rolelist)
        li =[]
        for j in pfr_role_list:
            each_role = Role.objects.filter(role_no=j)
            for k in each_role:    
                li.append(k.actors_name)

        round_actor_list.append(li)
    



    context = {
        "perform": perform_selected,
        "perform_rounds": perform_round,
        "rolelist": roles,
        "round_actors": round_actor_list,
    }

    return render(request, 'perform/rolelist.html', context)


def dateRound(request:HttpRequest):
    print('여까지 됨?')
    cancel_possible = 1
    pfr_dates_list = []
    pfr_round_list = []
    pfr_actors_list = []
    pfr_starttime_list = []
    pfr_pk_list = []
    date1 = list(request.POST.get('date1'))
    sort_index = date1.index('/')
  

   
    pf_no = int(((date1)[:sort_index])[0])

    selected_day = (request.POST.get('date1')[sort_index+1:])
    print((selected_day))
    try: 
        choose_pfr = PerformRound.objects.filter(perform_no=pf_no,pfr_date=selected_day )
    
    except Exception as e:
        print(e)


    

    for i in choose_pfr:
        pfr_dates_list.append(i.pfr_date)
        pfr_round_list.append(i.pfr_round)
        pfr_starttime_list.append(i.pfr_starttime)
        pfr_pk_list.append(i.no)

    for i in choose_pfr:
        pfr_role_list = eval(i.pfr_rolelist)
        li =[]
        for j in pfr_role_list:
            each_role = Role.objects.filter(role_no=j)
            for k in each_role:    
                li.append(k.actors_name)

        pfr_actors_list.append(li)

    # print('요까지는?')
    print(pfr_dates_list)
    



    return JsonResponse({ 
        "pfr_dates" : pfr_dates_list,
        "pfr_rounds" : pfr_round_list,
        "pfr_actors" : pfr_actors_list,
        "pfr_starttimes" : pfr_starttime_list,
        "pfr_pks" : pfr_pk_list,
  
        })



def chooseAjax(request:HttpRequest):
    cancel_possible = 1
    booked_seats = 0
    cancelTicket = True
    pfr_dates_list = []
    pfr_round_list = []
    pfr_actors_list = []
    pfr_starttime_list = []
    pfr_pk_list = []
    sel_starttime = None
    pfr_no = request.POST.get('date1')
    pfr = PerformRound.objects.get(no=pfr_no)
    choose_pfr = PerformRound.objects.filter(perform_no =pfr.perform_no,pfr_date=pfr.pfr_date)
    print(pfr)

    for i in choose_pfr:
        pfr_dates_list.append(i.pfr_date)
        pfr_round_list.append(i.pfr_round)
        pfr_starttime_list.append(i.pfr_starttime)
        pfr_pk_list.append(i.no)

    
    for i in choose_pfr:
        pfr_role_list = eval(i.pfr_rolelist)
        li = []
        for j in pfr_role_list:
            each_role = Role.objects.filter(role_no=j)
            for k in each_role:
                li.append(k.actors_name)
            
        pfr_actors_list.append(li)
    
    pfr_seats = Seat.objects.filter(pfr_no=pfr_no, seat_state=0)
    seats_types = []
    seats_type_names =[]

    for i in Seat.objects.filter(pfr_no=pfr_no):
        if i.seatType_no not in seats_types:
            seats_types.append(i.seatType_no)
            seats_type_names.append(i.seatType_no.seatType_name)

    
    seats_num_all = 0
    seats_num_type = {}
    seats_num_type_list = []

    for i in seats_types:
        seats_num_type[i.no] = 0

    for i in pfr_seats:
        seats_num_all += 1
        for j in seats_num_type:
  
            if i.seatType_no.no == j:
                seats_num_type[j] += 1



    for i in seats_num_type.keys():
        seats_num_type_list.append(seats_num_type[i])
    
    for i in Seat.objects.filter(pfr_no=pfr_no, seat_state=1):
        booked_seats +=1

    return JsonResponse({
    "pfr_no" : pfr_no,
    "pfr_dates" : pfr_dates_list,
    "pfr_rounds" : pfr_round_list,
    "pfr_actors" : pfr_actors_list,
    "pfr_starttimes" : pfr_starttime_list,
    "pfr_pks" : pfr_pk_list,
    "sts_type_names" : seats_type_names,
    "sts_num_all" : seats_num_all,
    "sts_num_type" : seats_num_type_list,
    "cancelticket" : cancelTicket,
    "cancel_possible" : cancel_possible,
    "pfr_starttime" : pfr.pfr_starttime,

        
    })

def rolelistAjax(request:HttpRequest):
    round_actor_list = []
    pf_no = None
    data = (request.POST.get('data'))
   
    try: data_list = list(map(int, data.split(',')))
    except:
        data_list = None
        print("아무것도 선택 안함")
    pf_no = data_list[0]
    selected_roles_list = data_list[1:]
    perform_round = PerformRound.objects.filter(perform_no = pf_no)
    round_selected = []
    for a in perform_round:
        pfr_roles = eval(a.pfr_rolelist)
        if all(b in pfr_roles for b in selected_roles_list):

            for b in selected_roles_list:
                round_selected.append(a.no)

    perform_round_selected = PerformRound.objects.filter(no__in=round_selected)
    pfr_dates = []
    pfr_times = []
    pfr_pks =[]
    for i in perform_round_selected:
        pfr_dates.append(i.pfr_date)
        pfr_times.append(i.pfr_starttime)
        pfr_pks.append(i.no)

    for i in perform_round_selected:
        pfr_role_list = eval(i.pfr_rolelist)
        li =[]
        for j in pfr_role_list:
            each_role = Role.objects.filter(role_no=j)
            for k in each_role:    
                li.append(k.actors_name)

        round_actor_list.append(li)
    
    print(round_selected) 
    return JsonResponse({
        "pf_no":pf_no,
        "selected_rounds": pfr_pks,
        "pfr_dates" : pfr_dates,
        "pfr_times" : pfr_times,
        "round_actors": round_actor_list,
                         })


def writeCheck(request:HttpRequest):
    member_id = request.session.get('login')
    star_score = int(request.POST.get('star_score'))
    review_content = request.POST.get('review_content')
    exceptation_content = request.POST.get('exceptation_content')
    pf_no = request.POST.get('pf_no')
    write_time = datetime.now()

    if star_score != 0:
        write_type = 1
        try:
            write = Write.objects.create(score=star_score,write_date=write_time,write_content=review_content,member_no_id=member_id,perform_no_id=pf_no,writetype_no_id=write_type)
        except Exception as e:
            print(e)
    else:
        write_type = 2
        try:
            write = Write.objects.create(score=None,write_date=write_time,write_content=exceptation_content,member_no_id=member_id,perform_no_id=pf_no,writetype_no_id=write_type)
        
        except Exception as e:
            print(e)

    return redirect('/perform/product/?pf_no='+pf_no)

##################################  예약 페이지 시작####################################
#           예약 페이지 1단계
def bkSchedule(request:HttpRequest):
    member_id = request.session.get('login')
    
    pfr_no = request.GET.get('pfr_no')

    member = Member.objects.get(member_no=member_id)
    perform_No = request.GET.get('perform_no')

    perform = Perform.objects.get(perform_no=perform_No)

    context = {
        "perform" : perform,
        "member" : member,

    }

    return render(request,'perform/booking/schedule.html', context)

def dateAjax(request:HttpRequest):
    cancel_possible = 1
    pfr_dates_list = []
    pfr_round_list = []
    pfr_actors_list = []
    pfr_starttime_list = []
    pfr_pk_list = []
    data = list(request.POST.get('data'))
    sort_index = data.index('/')

    pf_no = int(((data)[:sort_index])[0])

    selected_day = (request.POST.get('data')[sort_index+1:])
 
    try: 
        selected_pfr = PerformRound.objects.filter(perform_no=pf_no, pfr_date=selected_day )
    
    except Exception as e:
        print(e)

    
    

    for i in selected_pfr:
        pfr_dates_list.append(i.pfr_date)
        pfr_round_list.append(i.pfr_round)
        pfr_starttime_list.append(i.pfr_starttime)
        pfr_pk_list.append(i.no)

    for i in selected_pfr:
        pfr_role_list = eval(i.pfr_rolelist)
        li =[]
        for j in pfr_role_list:
            each_role = Role.objects.filter(role_no=j)
            for k in each_role:    
                li.append(k.actors_name)

        pfr_actors_list.append(li)



    return JsonResponse({
        "pfr_dates" : pfr_dates_list,
        "pfr_rounds" : pfr_round_list,
        "pfr_actors" : pfr_actors_list,
        "pfr_starttimes" : pfr_starttime_list,
        "pfr_pks" : pfr_pk_list,
  
                        })

def pfrAjax(request:HttpRequest):
    cancel_possible = 1
    booked_seats = 0
    cancelTicket = True
    pfr_dates_list = []
    pfr_round_list = []
    pfr_actors_list = []
    pfr_starttime_list = []
    pfr_pk_list = []
    sel_starttime = None
    pfr_no = request.POST.get('data')
    pfr = PerformRound.objects.get(no=pfr_no)
    selected_pfr = PerformRound.objects.filter(perform_no =pfr.perform_no,pfr_date=pfr.pfr_date)
    print(pfr)
    for i in selected_pfr:
        pfr_dates_list.append(i.pfr_date)
        pfr_round_list.append(i.pfr_round)
        pfr_starttime_list.append(i.pfr_starttime)
        pfr_pk_list.append(i.no)

    for i in selected_pfr:
        pfr_role_list = eval(i.pfr_rolelist)
        li =[]
        for j in pfr_role_list:
            each_role = Role.objects.filter(role_no=j)
            for k in each_role:    
                li.append(k.actors_name)

        pfr_actors_list.append(li)

    pfr_seats = Seat.objects.filter(pfr_no=pfr_no, seat_state=0)
    seats_types = []
    seats_type_names =[]
    for i in Seat.objects.filter(pfr_no=pfr_no):
        if i.seatType_no not in seats_types:
            seats_types.append(i.seatType_no)
            seats_type_names.append(i.seatType_no.seatType_name)


    seats_num_all = 0
    seats_num_type = {}
    seats_num_type_list = []
    for i in seats_types:
        seats_num_type[i.no] = 0

    for i in pfr_seats:
        seats_num_all += 1
        for j in seats_num_type:
  
            if i.seatType_no.no == j:
                seats_num_type[j] += 1
               

   
 


    for i in seats_num_type.keys():
        seats_num_type_list.append(seats_num_type[i])
    
    for i in Seat.objects.filter(pfr_no=pfr_no, seat_state=1):
        booked_seats +=1

                                 
    if booked_seats != 0:
        cancelTicket = False
    else:
        cancelTicket = True

    cancel_limit = pfr.pfr_date-timedelta(days=1)
    pfr_datetime = datetime.combine(pfr.pfr_date, datetime.min.time())


    canceltype_no = 0



    nowtime = datetime.now()

  
    days_difference = (pfr_datetime - nowtime).days
    if days_difference > 10:
        canceltype_no = 1
    elif 9 > days_difference >=7:
        canceltype_no = 2
    elif 7 > days_difference >=3:
        canceltype_no = 3
    elif 3 > days_difference >=1:
        canceltype_no = 4
    elif 1 > days_difference >= 0:
        canceltype_no = 5
    else:
        canceltype_no = 6

    
    cancel_type = CancelType.objects.get(no=canceltype_no)
    cancel_rate = cancel_type.ct_rate
    if cancel_type == 6:
        if nowtime.hour <= selected_pfr[0].pfr_starttime.hour:
            cancel_possible = 0
        

    
    if cancel_rate == None:
        cancel_rate = 0
    
    print(pfr)
    

    return JsonResponse({
        "pfr_no" : pfr_no,
        "pfr_dates" : pfr_dates_list,
        "pfr_rounds" : pfr_round_list,
        "pfr_actors" : pfr_actors_list,
        "pfr_starttimes" : pfr_starttime_list,
        "pfr_pks" : pfr_pk_list,
        "sts_type_names" : seats_type_names,
        "sts_num_all" : seats_num_all,
        "sts_num_type" : seats_num_type_list,
        "cancelticket" : cancelTicket,
        "cancel_limit" : cancel_limit,
        "cancel_possible" : cancel_possible,
        "cancel_rate" : cancel_rate*100,
        "pfr_starttime" : pfr.pfr_starttime,

        
                    })

#           예약 페이지 2단계


def bkSeat(request:HttpRequest):
    seat_name_list = []
    seat_type_list = []
    seat_su = 0
    seattype_names = []
    seattype_prices = []
    seattype_remains = []
    pf_no = request.GET.get('pf_no')
    member_id = request.session.get('login')
    pfr_no = request.GET.get('pfr_no')
    
    member = Member.objects.get(member_no=member_id)
    if pfr_no == '':
        return redirect('/perform/product/?pf_no='+pf_no)
    pfr = PerformRound.objects.get(no=pfr_no)
    perform = pfr.perform_no
    seats = Seat.objects.filter(pfr_no=pfr.no)
    for i in seats:
        seat_su += 1


    for i in seats:
        if i.seatType_no.no not in seat_type_list:
            seat_type_list.append(i.seatType_no.no)
            seattype_names.append(i.seatType_no.seatType_name)
            seattype_prices.append(i.seatType_no.seatType_price)

    for i in seat_type_list:
        each_remain = 0
        remain_seat_obj = Seat.objects.filter(seatType_no=i, seat_state=0, pfr_no=pfr_no)

        for i in remain_seat_obj:
            each_remain += 1

        seattype_remains.append(each_remain)
    
    print(seat_type_list)
    context = {
        "pfr" : pfr,
        "member" : member,
        "seat_name_list": seat_name_list,
        # "seat_state_list" : seat_state_list,
        "seat_type_list" : seat_type_list,
        "seats" : seats,
        "seat_su" : seat_su,
        "seattype_names" : seattype_names,
        "seattype_prices" : seattype_prices,
        "seattype_remains" : seattype_remains,
        "perform" : perform



    }   
    
    return render(request, 'perform/booking/seat.html', context)

def bkTicket(request:HttpRequest):
    global select_situation
    select_situation = {}
    seat_types = []
    seat_types_nums = {}
    posted_ticket_inform = request.POST.get('selection')
    pc0_seats = []
    pc0_pks = []
    seattypes_sales = {}
    pc0_rounds = {}
    seat_types_nums2 = {}
    print(posted_ticket_inform)

    seat_pks  = list(map(int, posted_ticket_inform.split(',')))
    
    pfr  = Seat.objects.get(no=seat_pks[0]).pfr_no
    perform = Perform.objects.get(perform_no=pfr.perform_no.perform_no)
    
  

    seats = Seat.objects.filter(no__in=seat_pks)
    
    for i in seats:
        if i.seatType_no.no not in seat_types:
            seat_types.append(i.seatType_no.no)
            seattypes_sales[i.seatType_no.no] = []

 
    
    seatTypes = SeatType.objects.filter(no__in=seat_types)

    for i in seatTypes:
        seat_types_nums[i.no] = 0
    for i in seat_types_nums:
        for j in seats:
            if i == j.seatType_no.no:
                seat_types_nums[i] += 1

    sale_rate = PerformCharge0.objects.filter(perform_no= perform.perform_no)
    for i in sale_rate:
        pc0_pks.append(i.no)
        pc0_seats.append(list(eval(i.pc0_seats)))
        pc0_rounds[i.no] = i.pc0_rounds


    for j in seat_types: # 각 좌석 타입에 맞는 pc0의 pk값 회차 조건없이 추가
        su = 0
        for i in pc0_seats:
            if j in i:
                seattypes_sales[j].append(pc0_pks[su])
            su += 1
    
               
             
    for key in seattypes_sales: # 회차 조건이 없는 경우 통과, 있는 경우 현재 회차가 포함 안될경우 삭제
        for value in seattypes_sales[key]:
            if pc0_rounds[value] != '':
                    if pfr.no not in list(eval(pc0_rounds[value])):
                       seattypes_sales[key].remove(value)

    for i in seat_types_nums:
        seat_types_nums2[i] = [seat_types_nums[i]]
                

    for key in seattypes_sales:
        new_list = []

        for value in seattypes_sales[key]:
            new_list.append(PerformCharge0.objects.get(no=value))
        seattypes_sales[key] = new_list

    for key in seat_types_nums2:
        new_dict = {}
 
        for value in seattypes_sales[key]:
            new_dict[value.no] = 0
        new_dict[0] = 0    
        new_list2 = seat_types_nums2[key]
        new_list2.append(new_dict)
        seat_types_nums2[key] = new_list2

    
    context = {
    "pfr" : pfr,
    "perform" : perform,
    "seats" : seats,
    "seattypes" :seatTypes,
    "seat_types_nums" : seat_types_nums,
    "seattypes_sales" : seattypes_sales,
    "seat_types_nums2" : seat_types_nums2,
    "posted_ticket_inform" : posted_ticket_inform
  
 

    }
    return render(request, 'perform/booking/ticket.html',context)

select_situation = {}

def ticketAjax(request:HttpRequest):
    tickets_price = 0
    total = 0
    booking_fee = 0
    sel_seats_su = 0
    global select_situation
    # print(SeatType_check)
 
    data = list(request.POST.get('data'))
    data2 = request.POST.get('data')
    print(data2)
    sort_index = data.index(',')
    sort_index2 = data.index('d')
    sort_index3 = data.index(']')+2
    selected_su = int(((data)[:sort_index])[0])
   
    user_seats = request.POST.get('data')[(sort_index2):]
    selected_seatType = (request.POST.get('data')[sort_index+1:sort_index2])
    data_list_str = user_seats[user_seats.index("[")+1 : user_seats.index("]")]
    data_list = eval(data_list_str)
    
    saleType = (data2[(sort_index3):])
    
    try: select_situation[selected_seatType][saleType] = selected_su


    except:
        select_situation[selected_seatType] = {}
        select_situation[selected_seatType][saleType] = selected_su
        print(select_situation)
        print('pass')

   

    for key in select_situation:
        normal_price = SeatType.objects.get(no=int(key)).seatType_price
        for pc0PK in select_situation[key]:
                if pc0PK == '0':
                    discount_rate = 1
                else:
                    discount_rate = (1- PerformCharge0.objects.get(no=int(pc0PK)).pc0_rate)
                selction_su = select_situation[key][pc0PK]
                booking_price = selction_su * 2000
                selction_price = round(normal_price * selction_su * discount_rate)
                tickets_price += selction_price
                booking_fee += booking_price
                sel_seats_su += selction_su
                


    print(select_situation)


    total = booking_fee + tickets_price
    # SeatType_check.append(selected_seatType)

    
    return JsonResponse({
        "booking_fee" : booking_fee,
        "ticket_price" : tickets_price,
        "total" : total,
        "selection_situation" : select_situation,
        "sel_seats_su" : sel_seats_su
    })

def bkTicket2(request:HttpRequest):
    pf_no = request.POST.get('ex_pf_no')
    perform = Perform.objects.get(perform_no = pf_no)
    pc1 = PerformCharge1.objects.filter(perform_no=pf_no)



    context = {
        "perform" : perform,
        "startdate" : perform.pf_startdate,
        "enddate" : perform.pf_enddate,
        "pc1" : pc1
       
        
        }
    

    return render(request,'perform/booking/ticket_ex.html', context)


def ticketAjax2(request:HttpRequest):
    data = request.POST.get('data')
    pc1_pkkist = []
    valuesData = []
    user_selection = eval(data)
    pc1_prices = []
    total = 0
    
    for i in user_selection:
        if type(i) == int:
            i = {i:user_selection[i]}
        for key in i:
            pc1_pkkist.append(key)
            valuesData.append(i[key])

    pc1s = PerformCharge1.objects.filter(no__in =pc1_pkkist)
 
    idx = 0
    for i in pc1s:

        pc1_prices.append(i.pc1_price)
        total += i.pc1_price * valuesData[idx]
        idx += 1

    print(user_selection)
    return JsonResponse({
        "total" : total,
        "selection" : user_selection


    })



def bkDelivery(request:HttpRequest):
    f_selection = request.POST.get('selection')
    f_booking_fee = request.POST.get('booking_fee')
    f_ticket_price = request.POST.get('ticket_price')
    f_total =  request.POST.get('total')
    login = request.session.get('login')
    logined_member = Member.objects.get(member_no=login)
    posted_ticket_inform = request.POST.get('posted_ticket_inform')
    print(posted_ticket_inform)

    seat_pks  = list(map(int, posted_ticket_inform.split(',')))
    seats = Seat.objects.filter(no__in=seat_pks)
    

    st_no_index2 = f_selection.index('"',2) 
    # (f_selection[2:st_no_index2]) # seatType pk값
    sampleSeatType = SeatType.objects.get(no=f_selection[2:st_no_index2])

    
    pfr = PerformRound.objects.get(no=seats[0].pfr_no.no)
    perform_No = pfr.perform_no
    perform = Perform.objects.get(perform_no=perform_No.perform_no) 
    cancel_limit = pfr.pfr_date-timedelta(days=1)
    pfr_datetime = datetime.combine(pfr.pfr_date, datetime.min.time())


    canceltype_no = 0



    nowtime = datetime.now()


    days_difference = (pfr_datetime - nowtime).days
    if days_difference > 10:
        canceltype_no = 1
    elif 9 > days_difference >=7:
        canceltype_no = 2
    elif 7 > days_difference >=3:
        canceltype_no = 3
    elif 3 > days_difference >=1:
        canceltype_no = 4
    elif 1 > days_difference >= 0:
        canceltype_no = 5
    else:
        canceltype_no = 6


    cancel_type = CancelType.objects.get(no=canceltype_no)
    cancel_rate = cancel_type.ct_rate
    if cancel_type == 6:
        if nowtime.hour <= pfr.pfr_starttime.hour:
            cancel_possible = 0
        

    
    if cancel_rate == None:
        cancel_rate = 0



    if perform.rw_no.no != 1:
        waypk_List = [1,perform.rw_no.no]

        receive_ways = RecieveWay.objects.filter(no__in=waypk_List)
    else:   
        receive_ways = RecieveWay.objects.filter(no=1)

    print(perform.rw_no.no )

    context = {
        "perform" : perform,
        "pfr": pfr,
        "member" : logined_member,
        "seats" :seats,
        "booking_fee" : f_booking_fee,
        "ticket_price" : f_ticket_price,
        "cancel_limit" : cancel_limit,
        "cancel_type" :cancel_type,
        "receive_ways" :receive_ways,
        "selection" : f_selection,
        "seats_pks" : seat_pks

        


    }

    return render(request, 'perform/booking/delivery.html',context)

def bkDelivery2(request:HttpRequest):
    ex_pf_no = request.POST.get('perform')
    f_selection = request.POST.get('selection')
    f_total =  request.POST.get('total')
    login = request.session.get('login')
    logined_member = Member.objects.get(member_no=login)
    perform = Perform.objects.get(perform_no=ex_pf_no)
    print(f_total)
    print((f_selection))
    



    nowtime = datetime.now()


    days_difference = (datetime.combine(perform.pf_enddate, datetime.min.time()) - nowtime).days
    if days_difference > 10:
        canceltype_no = 1
    elif 9 > days_difference >=7:
        canceltype_no = 2
    elif 7 > days_difference >=3:
        canceltype_no = 3
    elif 3 > days_difference >=1:
        canceltype_no = 4
    elif 1 > days_difference >= 0:
        canceltype_no = 5
    else:
        canceltype_no = 6


    perform = Perform.objects.get(perform_no = ex_pf_no)
        
    cancel_type = CancelType.objects.get(no=canceltype_no)
    cancel_rate = cancel_type.ct_rate
    if cancel_type == 6:
        cancel_possible = 0
        

    
    if cancel_rate == None:
        cancel_rate = 0


    if perform.rw_no.no != 1:
        waypk_List = [1,perform.rw_no.no]

        receive_ways = RecieveWay.objects.filter(no__in=waypk_List)
    else:   
        receive_ways = RecieveWay.objects.filter(no=1)


    context = {
        "perform" : perform,
        "member" : logined_member,
        "cancel_type" :cancel_type,
        "receive_ways" :receive_ways,
        "selection" : f_selection,
        "total" :f_total
    }

    return render(request, 'perform/booking/delivery_ex.html',context)


def bkComplete(request:HttpRequest):
    memberNo = request.session.get('login')
    tickets_su = 0
 
    user_name = Member.objects.get(member_no=memberNo).name
    member_No = Member.objects.get(member_no=memberNo)
    total_input = int((request.POST.get('total_input')))
    selection =(request.POST.get('selection'))
    zip_code =(request.POST.get('zip_code'))
    rw = int(request.POST.get('rw'))
    rw_No = RecieveWay.objects.get(no=rw)
    user_phone = (request.POST.get('user_phone'))
    user_email = (request.POST.get('user_email'))
    rw_name = (request.POST.get('rw_name'))
    rw_phone = (request.POST.get('rw_phone'))
    rw_address = (request.POST.get('rw_address'))

    seatsData = request.POST.get('seats_pks')
 

    if seatsData != '':  # 공연 예매
        bk_Seats = eval(seatsData)
        seatSample = Seat.objects.get(no= int(eval(seatsData)[0]))
        pfrNo = seatSample.pfr_no
        for i in eval((selection)):
            j = eval((selection))[i]
            for k in j:
                tickets_su += j[k]

        newBooking = Booking.objects.create(member_no=member_No,pfr_no=pfrNo,rw_no=rw_No,bk_tknum=tickets_su,bk_seats=bk_Seats,bk_total=total_input,bk_info=selection,bk_state=True, bk_bkname=user_name,bk_bkphone=user_phone,bk_bkemail=user_email ,bk_rw_name=rw_name, bk_rw_phone=rw_phone, bk_rw_address=rw_address, bk_rw_zipcode=zip_code)
        print(newBooking)


        bk_Seats = eval(seatsData)
        for i in bk_Seats:
            booked_seats= Seat.objects.get(no=int(i))
            booked_seats.seat_state = 1
            booked_seats.save()

    else: #전시 예매
        for i in eval(selection):
            if type(i) == int:
                i = {i:eval(selection)[i]}
            for j in i:
                tickets_su += i[j]
            pc1_sample_no = j
        pc1Sample = PerformCharge1.objects.get(no =pc1_sample_no)
        perform_sample = pc1Sample.perform_no
        pfr_No = PerformRound.objects.get(perform_no=perform_sample.perform_no)


        newBooking = Booking.objects.create(member_no=member_No,pfr_no = pfr_No,rw_no=rw_No,bk_tknum=tickets_su,bk_total=total_input,bk_info=selection,bk_state=True, bk_bkname=user_name,bk_bkphone=user_phone,bk_bkemail=user_email ,bk_rw_name=rw_name, bk_rw_phone=rw_phone, bk_rw_address=rw_address, bk_rw_zipcode=zip_code)

    return render(request,'perform/booking/complete.html')


def wtSelectSeat(requset:HttpRequest):

    pfr_no = requset.GET.get('pfr_no')
    print(requset.GET.get('pfr_no'))
    pfr = PerformRound.objects.get(no=pfr_no)
    cancel_limit = pfr.pfr_date-timedelta(days=1)
    
    seat_name_list = []
    seat_type_list = []
    seat_su = 0
    seattype_names = []
    seattype_prices = []
    seattype_remains = []
    
    member_id = requset.session.get('login')

    member = Member.objects.get(member_no=member_id)

    seats = Seat.objects.filter(pfr_no=pfr.no)
    for i in seats:
        seat_su += 1


    for i in seats:
        if i.seatType_no.no not in seat_type_list:
            seat_type_list.append(i.seatType_no.no)
            seattype_names.append(i.seatType_no.seatType_name)
            seattype_prices.append(i.seatType_no.seatType_price)

    for i in seat_type_list:
        each_remain = 0
        remain_seat_obj = Seat.objects.filter(seatType_no=i, seat_state=0, pfr_no=pfr_no)

        for i in remain_seat_obj:
            each_remain += 1

        seattype_remains.append(each_remain)

    context = {
   
           "pfr" : pfr,
        "member" : member,
        "seat_name_list": seat_name_list,
        # "seat_state_list" : seat_state_list,
        "seat_type_list" : seat_type_list,
        "seats" : seats,
        "seat_su" : seat_su,
        "seattype_names" : seattype_names,
        "seattype_prices" : seattype_prices,
        "seattype_remains" : seattype_remains,
        "cancel_limit" : cancel_limit



    }


    return render(requset,'perform/waiting/selectseat.html',context)



def wtComplete(request:HttpRequest):
    member_id = request.session.get('login')
    member = Member.objects.get(member_no=member_id)
    wait_fee = request.POST.get('wait_fee')
    selection = request.POST.get('selection')
    email = request.POST.get('email')
    phone = request.POST.get('phone')
    if type(eval(selection)) == int:
        insert_selection = str(selection)
        sampleSeat = Seat.objects.get(no= (insert_selection))
        print('dlrjehla')
    else:
        insert_selection = selection
        sampleSeat = Seat.objects.get(no= eval(insert_selection)[0])
    print(type(selection))

    
    pfr = sampleSeat.pfr_no
    print(pfr)
    CCTs = CancelTicket.objects.filter(pfr_no=pfr)
    new_priorty = 1
    for i in CCTs:
        new_priorty += 1

    ticket_num = 0

    if CancelTicket.objects.filter(member_no=member, pfr_no=pfr).__len__() != 0:
        message = "모든 사용자는 각 회차당 한 번만 취소표 신청이 가능합니다!"
    else:
        if type(eval(selection)) == int:
            ticket_num = 1
        else:
            for i in eval(selection):
                ticket_num +=1


    
        

        try: 
            newCCT = CancelTicket.objects.create(cct_num=ticket_num,cct_seats=selection, cct_phone=phone, cct_address=email, cct_charge=int(wait_fee),cct_priorty=new_priorty,member_no=member,pfr_no=pfr)
            message = '취소표 신청에 성공하셨습니다!'
            if type(eval(selection)) == int:
                seat = Seat.objects.get(no=int(selection))
                seat_cct_su_new = seat.seat_cts + 1
                seat.seat_cts = seat_cct_su_new
                seat.save()


            else:
                for i in eval(selection):
                    seat = Seat.objects.get(no=int(i))
                    seat_cct_su_new = seat.seat_cts + 1
                    seat.seat_cts = seat_cct_su_new
                    seat.save()

        except:
            message = "취소표 신청에 실패했습니다!"
        


    
    


    context = {

        "message" : message
    }

    return render(request,'perform/waiting/complete.html' ,context)


def ccCheck(request:HttpRequest):
    bk_no = request.GET.get('no')
    banks = Bank.objects.all()
    book = Booking.objects.get(no=bk_no)
    pfr = PerformRound.objects.get(no=book.pfr_no.no)
    perform = Perform.objects.get(perform_no= pfr.perform_no.perform_no)
    seats = Seat.objects.filter(no__in=json.loads(book.bk_seats))
    seatslist = ''
    for i in seats:
        seatslist += i.seat_name
        seatslist += ', '
        
    
    if seatslist.endswith(', '):
        seatslist = seatslist[:-2]
    print(seatslist)    
    cancel_possible = "가능"
    nowtime = datetime.now()
    pfr_datetime = (datetime.combine(pfr.pfr_date, datetime.min.time()) - nowtime).days
    days_difference = pfr_datetime
    if days_difference > 10:
        canceltype_no = 1
    elif 9 > days_difference >=7:
        canceltype_no = 2
    elif 7 > days_difference >=3:
        canceltype_no = 3
    elif 3 > days_difference >=1:
        canceltype_no = 4
    elif 1 > days_difference >= 0:
        canceltype_no = 5
    else:
        canceltype_no = 6
        if nowtime.hour <= pfr.pfr_starttime.hour:
            cancel_possible = "불가능"
        else:
            cancel_possible = "가능"
    


      
    cancel_type = CancelType.objects.get(no=canceltype_no)
    cancel_rate = cancel_type.ct_rate
  
    if cancel_rate == None:
        cancel_rate = 0

    refund = (1-cancel_rate) * book.bk_total

    context = {
        "booking" :book,
        "banks" : banks,
        "perform" : perform,
        "pfr" : pfr,
        "cancel_type" : cancel_type,
        "seats" :seats,
        "seatslist" : seatslist,
        "cancel_possible" : cancel_possible,
        "refund" : refund,
    
    


    }
    return render(request,'perform/canceling/check.html', context)

def pwCheck(request:HttpRequest):
    insertPW = request.POST.get('data')
    realPW = Member.objects.get(member_no=request.session.get('login')).password
    ck_result = insertPW == realPW
    print(ck_result)
    print(insertPW)
    
    return JsonResponse({"result":ck_result})


def ccComplete(request:HttpRequest):
    bk_no = request.POST.get('bk_no')
    bk = Booking.objects.get(no=bk_no)
    refundmoney = request.POST.get('refund')
    ct_no = request.POST.get('ct_no')
    ct = CancelType.objects.get(no=ct_no)
    print(int(float(refundmoney)))
    bankname = request.POST.get('bank')
    account = request.POST.get('bk_account')
    
    bk.bk_state = 0
    bk.save() # 예약 취소 완료

    seatlist = json.loads(bk.bk_seats)
    sampleSeat = Seat.objects.get(no=seatlist[0])
    pfr = sampleSeat.pfr_no
    # print(seatlist)

    pfr_ccts = CancelTicket.objects.filter(pfr_no=pfr, cct_state=0) # 해당 최차의 취소표 전
    
    
    print(pfr_ccts)
    print(bk.bk_seats)
    pfr_ccts.order_by('cct_priorty')
    print(pfr_ccts)
    bk_seats = json.loads(bk.bk_seats)
    print(type(bk_seats))
    for i in pfr_ccts:
        ccts_seats = []
        data = '[' + i.cct_seats +']'
        for j in json.loads(data):
            if j in bk_seats:
                ccts_seats.append(j)
                each_seat = Seat.objects.get(no=j)
                seats_cts_num = each_seat.seat_cts
                each_seat.seat_cts = seats_cts_num -1
                bk_seats.remove(j)
        i.cct_state = 1
        i.save()
        try:
                
            newPriorty = Priorty.objects.create(pr_seats=ccts_seats,cct_no=i,pfr_no=pfr)
            print('우선순위 생성!')
        except:
            newPriorty = None
            print('우선순위 생성 실패!')
            



    try:
        newBKcancel = BkCancel.objects.create(bkc_refund=int(float(refundmoney)),bkc_account=account,bkc_bank=bankname,bk_no=bk,ct_no=ct)
        message = '예약 취소에 성공했습니다!'
    
    except:
        newBKcancel = None
        message = "예약 취소에 실패했습니다."

       

    context = {
        "message" : message
    }
    print('여기까지')
    return render(request,'perform/canceling/complete.html', context)


def prCheck(request:HttpRequest):
    pr_no = request.GET.get('pr_no')
    priorty = Priorty.objects.get(no=pr_no)
    cancelTicket = CancelTicket.objects.get(no=(priorty.cct_no.no))
    booking_fee = 0
    tickets_price = 0
    if type(eval(cancelTicket.cct_seats)) == int:
        seats = Seat.objects.filter(no=cancelTicket.cct_seats)
       
    else:
        seats = Seat.objects.filter(no__in=eval(cancelTicket.cct_seats))
    print(cancelTicket.cct_seats)
    seats_names = ''
    for i in seats:
        seats_names += (i.seat_name)
        seats_names += ', '
        booking_fee += 2000
        tickets_price += i.seatType_no.seatType_price
    if seats_names.endswith(', '):
        seats_names = seats_names[:-2]
    print(seats_names)
    print(tickets_price)
    seats_dict = {}
    for i in seats:
        seats_dict[i.seatType_no.seatType_name] = 0
    for i in seats_dict:
        for j in seats:
            if i == j.seatType_no.seatType_name:
                seats_dict[i] += 1
  
    pfr = seats[0].pfr_no
    cancelTicket.cct_state = 2
    cancelTicket.save()

    context = {
        "seats" : seats,
        "seats_names" : seats_names,
        "seats_dict" : seats_dict,
        "pfr" : pfr,
        "booking_fee" : booking_fee,
        "tickets_price" : tickets_price,
        "seats_inform" : cancelTicket.cct_seats
   


    }

    return render(request,'perform/priorty/check.html', context)

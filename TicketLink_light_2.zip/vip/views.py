from django.shortcuts import render
from django.http import HttpRequest

from TicketLink.models import Member,Vip
from TicketLink.models import  Perform
# from TicketLink.models import Document, DocCate, CancelTicket, Priorty, RefundAccount

# Create your views here.


def index(request:HttpRequest):
    try:
        member = Member.objects.get(member_no = request.session.get('login'))
    except Exception as e:
        print(e)
        member = None
    list = Perform.objects.filter(perform_no__lte = 4)
    vip = Vip.objects.get(vip_no = 4)
    context = {
        "member" : member,
        "list" : list,
        "vip" : vip,
    }
    return render(request, 'vip/index.html', context)